
import React, { useState, useEffect } from 'react';
import { Profile, Gender, MaritalStatus } from '../types';
import { RELIGIONS, CASTES, DISTRICTS, ADMIN_PHONE } from '../constants';
import { MapPin, User, Briefcase, GraduationCap, CheckCircle, Heart, Phone, Info, Stethoscope, FileText, Users } from 'lucide-react';

interface ProfileCardProps {
  profile: Profile;
  showPhone?: boolean;
  onPhoneClick?: () => void;
}

const ProfileCard: React.FC<ProfileCardProps> = ({ profile, showPhone, onPhoneClick }) => {
  const [showPopup, setShowPopup] = useState(false);

  const religion = RELIGIONS.find(r => r.id === profile.religionId)?.name;
  const casteList = CASTES[profile.religionId] || [];
  const caste = casteList[profile.casteId - 1] || casteList[0] || 'Other';

  useEffect(() => {
    if (showPopup) {
      const timer = setTimeout(() => setShowPopup(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [showPopup]);

  return (
    <div className="bg-white rounded-[2.5rem] overflow-hidden shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-500 group relative flex flex-col h-full">
      <div className="relative aspect-[3/4] overflow-hidden">
        <img 
          src={profile.photoUrl} 
          alt={profile.nickname}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2000ms]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
        <div className="absolute bottom-4 left-6 right-6 text-white space-y-1">
          <div className="flex items-center gap-2">
            <h3 className="text-2xl font-black tracking-tighter">{profile.nickname}</h3>
            {profile.isVerified && <CheckCircle className="w-4 h-4 text-emerald-400 fill-emerald-400" />}
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest opacity-60">{profile.id}</p>
          <p className="text-xs font-bold">{profile.age}y • {profile.height}cm • {profile.bodyType}</p>
        </div>
        <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-[9px] font-black text-white uppercase tracking-tighter">
          {profile.maritalStatus === MaritalStatus.FIRST ? 'First' : 'Second'} Marriage
        </div>
      </div>

      <div className="p-6 space-y-4 flex-grow flex flex-col">
        <div className="space-y-2 text-[11px] font-bold text-gray-500 flex-grow">
          <div className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-rose-500" /> {profile.district}</div>
          <div className="flex items-center gap-2"><User className="w-3.5 h-3.5 text-rose-500" /> {religion} • {caste}</div>
          <div className="flex items-center gap-2"><GraduationCap className="w-3.5 h-3.5 text-rose-500" /> {profile.educationLevel}</div>
          <div className="flex items-center gap-2"><Briefcase className="w-3.5 h-3.5 text-rose-500" /> {profile.occupation}</div>
          
          <div className="mt-4 pt-4 border-t border-gray-50 space-y-3">
             <div className="flex items-center justify-between text-[10px] text-gray-400 uppercase tracking-tighter">
                <span className="flex items-center gap-1"><Users className="w-3 h-3"/> Siblings</span>
                <span className="font-black text-gray-600">{profile.siblings.length} Members</span>
             </div>
             
             {profile.healthDisclosure && (
               <div className="p-2.5 bg-rose-50/50 rounded-xl border border-rose-100/50 text-[10px] text-rose-700 leading-relaxed italic">
                 <span className="font-black uppercase tracking-widest text-[8px] block mb-1 not-italic text-rose-400">Health Note</span>
                 "{profile.healthDisclosure}"
               </div>
             )}

             {profile.additionalDetails && (
               <div className="p-2.5 bg-blue-50/50 rounded-xl border border-blue-100/50 text-[10px] text-blue-700 leading-relaxed italic">
                 <span className="font-black uppercase tracking-widest text-[8px] block mb-1 not-italic text-blue-400">Disclosures</span>
                 "{profile.additionalDetails}"
               </div>
             )}
          </div>
        </div>

        {showPhone ? (
          <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-xl border border-emerald-100">
            <span className="text-[10px] font-black text-emerald-800 uppercase tracking-widest">Phone</span>
            <a href={`tel:${profile.phone}`} onClick={onPhoneClick} className="font-mono text-emerald-600 font-bold hover:underline flex items-center gap-1">
              <Phone className="w-3 h-3" /> {profile.phone}
            </a>
          </div>
        ) : (
          <button 
            onClick={() => setShowPopup(true)}
            className="w-full py-4 bg-rose-600 text-white font-black rounded-2xl hover:bg-rose-700 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"
          >
            <Heart className="w-4 h-4" /> Connect with Soul
          </button>
        )}
      </div>

      {showPopup && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="bg-white rounded-[3rem] p-10 max-w-sm w-full text-center shadow-2xl animate-in zoom-in border border-gray-100">
            <Heart className="w-12 h-12 text-rose-600 fill-rose-600 mx-auto mb-6" />
            <h4 className="text-2xl font-black text-gray-900 mb-2">Request Intro</h4>
            <p className="text-gray-500 text-sm mb-8">Call admin to get contact of {profile.nickname}:</p>
            <a href={`tel:${ADMIN_PHONE}`} className="text-3xl font-black text-rose-600 block">{ADMIN_PHONE}</a>
            <p className="text-[10px] font-black text-gray-300 mt-6 tracking-widest uppercase">Authorized Helpdesk Only</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileCard;
