
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Profile, Staff } from '../types';
import { LogOut, Heart, ShieldCheck, Shield, User, LayoutDashboard } from 'lucide-react';
import { SUPPORT_EMAIL } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  currentUser: Profile | null;
  currentStaff: Staff | null;
  isSuperAdmin: boolean;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentUser, currentStaff, isSuperAdmin, onLogout }) => {
  const location = useLocation();
  const isAdminPath = location.pathname.startsWith('/admin');
  const showBlurredBg = currentUser && !isAdminPath && (location.pathname === '/' || location.pathname === '/profile');

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-gray-50">
      {showBlurredBg && (
        <div 
          className="fixed inset-0 z-0 transition-opacity duration-1000"
          style={{
            backgroundImage: `url(${currentUser.photoUrl})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.1,
            filter: 'blur(40px)',
            transform: 'scale(1.1)'
          }}
        />
      )}

      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-rose-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="w-10 h-10 bg-rose-600 rounded-xl flex items-center justify-center shadow-lg group-hover:rotate-6 transition-transform">
                <Heart className="w-6 h-6 text-white fill-white" />
              </div>
              <span className="text-2xl font-black bg-gradient-to-r from-rose-600 to-amber-600 bg-clip-text text-transparent">
                SoulLinks
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link to="/" className="text-gray-600 hover:text-rose-600 font-bold transition-colors">Home</Link>
              {(currentUser || currentStaff || isSuperAdmin) && <Link to="/matches" className="text-gray-600 hover:text-rose-600 font-bold">Matches</Link>}
              {currentStaff && <Link to="/staff" className="flex items-center gap-1 text-rose-600 font-black"><Shield className="w-4 h-4" /> Staff Desk</Link>}
              {isSuperAdmin && <Link to="/admin" className="flex items-center gap-1 text-gray-900 font-black"><ShieldCheck className="w-4 h-4" /> Root Admin</Link>}
            </div>

            <div className="flex items-center space-x-4">
              {currentUser || currentStaff || isSuperAdmin ? (
                <div className="flex items-center gap-4">
                  {currentUser && (
                    <Link to="/profile" className="flex items-center space-x-2 p-1 pl-4 bg-rose-50 rounded-full border border-rose-100 hover:bg-rose-100">
                      <span className="text-sm font-black text-rose-700">{currentUser.nickname}</span>
                      <img src={currentUser.photoUrl} className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm" />
                    </Link>
                  )}
                  {currentStaff && (
                    <div className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-rose-500/20">
                      <Shield className="w-3 h-3" /> {currentStaff.name}
                    </div>
                  )}
                  {isSuperAdmin && (
                    <div className="px-4 py-2 bg-gray-900 text-white rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-xl">
                      <ShieldCheck className="w-3 h-3 text-rose-500" /> Root Console
                    </div>
                  )}
                  <button onClick={onLogout} className="p-3 text-gray-400 hover:text-rose-600 bg-gray-50 rounded-2xl transition-all"><LogOut className="w-5 h-5" /></button>
                </div>
              ) : (
                <Link to="/login" className="px-6 py-3 bg-rose-600 text-white font-black rounded-2xl shadow-lg hover:bg-rose-700 transition-all active:scale-95">Member Login</Link>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow relative z-10">{children}</main>

      <footer className="bg-gray-950 text-gray-500 py-16 relative z-10 border-t border-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-2 space-y-6">
              <div className="flex items-center space-x-2">
                <Heart className="w-8 h-8 text-rose-500 fill-rose-500" />
                <span className="text-2xl font-black text-white">SoulLinks Matrimony</span>
              </div>
              <p className="text-sm leading-relaxed max-w-sm">
                Kerala's premier free marriage platform for first and second marriages. Authorized by Brilliant International. Dating is strictly prohibited.
              </p>
              <div className="flex items-center gap-2 text-rose-500 font-bold">
                <ShieldCheck className="w-5 h-5" />
                Verified & Secured by SoulLinks Root
              </div>
            </div>
            <div>
              <h4 className="text-white font-black uppercase text-xs tracking-[0.2em] mb-6">Support</h4>
              <ul className="text-sm space-y-4 font-medium">
                <li>Hours: 3:30 PM - 6:00 AM</li>
                <li>Email: {SUPPORT_EMAIL}</li>
                <li className="text-rose-400">Admin: +91 6352 692 909</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-black uppercase text-xs tracking-[0.2em] mb-6">Security</h4>
              <ul className="text-sm space-y-4 font-medium">
                <li>• OTP Mandatory Access</li>
                <li>• End-to-End Encryption</li>
                <li>• IP Restricted Admin</li>
                <li>• Non-Removable Watermarks</li>
              </ul>
            </div>
          </div>
          <div className="mt-16 pt-8 border-t border-gray-900 text-center text-xs tracking-widest uppercase">
            © {new Date().getFullYear()} SoulLinks Matrimony. Built for Tradition. Managed by Brilliant International.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
