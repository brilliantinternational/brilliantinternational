
import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Lock, X, Eye, EyeOff, Loader2, Smartphone, AlertCircle, Info } from 'lucide-react';
import { Profile, Staff } from '../types';

interface ForgotPasswordModalProps {
  onClose: () => void;
  onReset: (phone: string, newPassword: string) => void;
  profiles: Profile[];
  staff: Staff[];
}

const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ onClose, onReset, profiles, staff }) => {
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const validatePassword = (pass: string) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(pass);
  };

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    
    const cleanPhone = phone.trim();
    if (cleanPhone.length < 10) {
      setErrorMessage("Please enter a valid 10-digit phone number");
      return;
    }

    // Verify account exists in profiles or staff
    const exists = profiles.some(p => p.phone === cleanPhone) || staff.some(s => s.phone === cleanPhone);
    
    if (!exists) {
      setErrorMessage("No account found with this phone number.");
      return;
    }

    setIsSending(true);
    
    // Simulate network delay for sending SMS
    setTimeout(() => {
      setIsSending(false);
      setStep(2);
    }, 1200);
  };

  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp === '1234') {
      setStep(3);
    } else {
      alert("Invalid verification code. Please use the demo code: 1234");
    }
  };

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validatePassword(newPassword)) {
      alert("Password security error: Must contain Capital, Small, Numbers, and Special characters (minimum 8 characters).");
      return;
    }
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match. Please try again.");
      return;
    }
    onReset(phone.trim(), newPassword);
    alert("Password updated successfully! You can now log in with your new password.");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div className="bg-white rounded-[2.5rem] p-8 md:p-12 max-w-md w-full shadow-2xl relative animate-in zoom-in duration-300">
        <button 
          type="button"
          onClick={onClose} 
          disabled={isSending}
          className="absolute top-6 right-6 text-gray-400 hover:text-gray-600 transition-colors disabled:opacity-50"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="text-center space-y-4 mb-8">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto transition-all ${isSending ? 'bg-amber-100 animate-pulse scale-110' : 'bg-rose-100'}`}>
            {isSending ? <Loader2 className="w-8 h-8 text-amber-600 animate-spin" /> : <Lock className="w-8 h-8 text-rose-600" />}
          </div>
          <h2 className="text-2xl font-black text-gray-900">
            {step === 1 && (isSending ? "Initiating Secure Send..." : "Reset Password")}
            {step === 2 && "Identity Verification"}
            {step === 3 && "Secure Profile"}
          </h2>
          <div className="text-gray-500 text-sm leading-relaxed">
            {step === 1 && (isSending ? <p>Routing through security gateway...</p> : <p>Enter your registered phone number to receive a verification code.</p>)}
            {step === 2 && <p>We've simulated a security code delivery to: <br/><b className="text-rose-600">{phone}</b></p>}
            {step === 3 && <p>Identity verified! Choose a new high-security password.</p>}
          </div>

          {step === 2 && (
             <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-500">
              <div className="flex items-center justify-center gap-2 text-rose-600 font-black text-sm uppercase tracking-widest mb-1">
                <Info className="w-4 h-4" /> Demo Security Code
              </div>
              <p className="text-3xl font-black text-rose-700 tracking-[0.5em] ml-[0.5em]">1234</p>
            </div>
          )}
        </div>

        {step === 1 && (
          <form onSubmit={handleSendOTP} className="space-y-6">
            <div className="space-y-2">
              <div className="relative group">
                <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
                <input 
                  type="tel" 
                  placeholder="Registered Phone Number" 
                  required 
                  disabled={isSending}
                  className={`w-full pl-12 pr-4 py-4 bg-gray-50 border rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none text-center font-bold disabled:opacity-50 transition-all ${errorMessage ? 'border-rose-300' : 'border-gray-100'}`}
                  value={phone} 
                  onChange={e => {
                    setPhone(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                />
              </div>
              
              {errorMessage && (
                <div className="flex items-center gap-2 text-rose-600 text-xs font-bold px-2 animate-in fade-in slide-in-from-top-1">
                  <AlertCircle className="w-3 h-3" />
                  {errorMessage}
                </div>
              )}

              <div className="p-3 bg-blue-50 rounded-xl border border-blue-100 mt-2">
                <p className="text-[10px] text-blue-700 font-bold leading-relaxed flex items-start gap-2">
                  <span className="bg-blue-600 text-white px-1.5 rounded">DEMO</span>
                  Valid account: 9876543210
                </p>
              </div>
            </div>

            <button 
              type="submit" 
              disabled={isSending}
              className="w-full bg-rose-600 text-white font-black py-4 rounded-2xl shadow-xl hover:bg-rose-700 transition-all flex items-center justify-center gap-2 disabled:bg-rose-400 disabled:scale-95 active:scale-95"
            >
              {isSending ? "Processing..." : "Get Verification Code"} 
              {!isSending && <ArrowRight className="w-4 h-4" />}
            </button>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={handleVerifyOTP} className="space-y-6">
            <div className="space-y-2">
              <input 
                type="text" 
                placeholder="0000" 
                maxLength={4} 
                required
                className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl text-center text-3xl font-bold tracking-[0.5em] outline-none focus:ring-2 focus:ring-rose-500"
                value={otp} 
                onChange={e => setOtp(e.target.value)}
                autoFocus
              />
            </div>
            <button type="submit" className="w-full bg-rose-600 text-white font-black py-4 rounded-2xl shadow-xl hover:bg-rose-700 transition-all flex items-center justify-center gap-2 active:scale-95">
              Verify & Proceed <ShieldCheck className="w-4 h-4" />
            </button>
            <button type="button" onClick={() => setStep(1)} className="w-full text-xs font-bold text-gray-400 hover:text-rose-600 transition-colors">Change Phone Number</button>
          </form>
        )}

        {step === 3 && (
          <form onSubmit={handleResetSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">New Secure Password</label>
              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"} 
                  placeholder="At least 8 characters" 
                  required
                  className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 font-bold"
                  value={newPassword} 
                  onChange={e => setNewPassword(e.target.value)}
                  autoFocus
                />
                <button 
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-rose-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Confirm Password</label>
              <input 
                type={showPassword ? "text" : "password"} 
                placeholder="Repeat new password" 
                required
                className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 font-bold"
                value={confirmPassword} 
                onChange={e => setConfirmPassword(e.target.value)}
              />
            </div>
            <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100">
              <p className="text-[10px] text-rose-700 font-bold leading-relaxed uppercase tracking-tighter">
                Security Checklist: Capital + Small + Numbers + Symbols (@$!%*?&).
              </p>
            </div>
            <button type="submit" className="w-full bg-gray-900 text-white font-black py-4 rounded-2xl shadow-xl hover:bg-black transition-all active:scale-95 mt-4">
              Update & Login
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPasswordModal;
