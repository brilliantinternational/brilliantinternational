
import React, { useState, useEffect } from 'react';
import { Phone, ArrowRight, X, Loader2, ShieldCheck, Info } from 'lucide-react';

interface OTPModalProps {
  onVerify: () => void;
  onCancel: () => void;
  target: string;
}

const OTPModal: React.FC<OTPModalProps> = ({ onVerify, onCancel, target }) => {
  const [code, setCode] = useState('');
  const [isSending, setIsSending] = useState(true);
  const [showCodeHint, setShowCodeHint] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsSending(false);
      // Automatically show the hint after a short delay if they don't enter anything
      setTimeout(() => setShowCodeHint(true), 1000);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === '1234') {
      onVerify();
    } else {
      alert("Verification failed. In this demo mode, please enter the security code: 1234");
    }
  };

  const handleResend = () => {
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setShowCodeHint(true);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div className="bg-white rounded-[2.5rem] p-8 md:p-12 max-w-md w-full shadow-2xl relative animate-in zoom-in duration-300">
        <button onClick={onCancel} className="absolute top-6 right-6 text-gray-400 hover:text-gray-600 transition-colors">
          <X className="w-6 h-6" />
        </button>

        <div className="text-center space-y-4">
          <div className={`w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto transition-all ${isSending ? 'animate-pulse scale-110' : ''}`}>
            {isSending ? <Loader2 className="w-8 h-8 text-rose-600 animate-spin" /> : <ShieldCheck className="w-8 h-8 text-rose-600" />}
          </div>
          <h2 className="text-2xl font-black text-gray-900">
            {isSending ? 'Sending Security Code...' : 'Phone Verification'}
          </h2>
          <div className="text-gray-500 text-sm leading-relaxed">
            {isSending 
              ? <p>Connecting to SoulLinks SMS Gateway for <b className="text-rose-600">{target}</b>...</p>
              : <p>We've simulated a security code delivery to: <br/><b className="text-rose-600">{target}</b></p>
            }
          </div>
          
          {showCodeHint && !isSending && (
            <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-500">
              <div className="flex items-center justify-center gap-2 text-rose-600 font-black text-sm uppercase tracking-widest mb-1">
                <Info className="w-4 h-4" /> Security Code
              </div>
              <p className="text-3xl font-black text-rose-700 tracking-[0.5em] ml-[0.5em]">1234</p>
              <p className="text-[10px] text-rose-400 font-bold mt-2 uppercase">Enter this code below to proceed</p>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className={`mt-8 space-y-6 transition-all duration-500 ${isSending ? 'opacity-20 blur-sm pointer-events-none' : 'opacity-100'}`}>
          <div className="space-y-1">
            <input 
              type="text" 
              placeholder="0000" 
              maxLength={4}
              required
              className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl text-center text-3xl font-bold tracking-[1rem] focus:ring-2 focus:ring-rose-500 outline-none transition-all"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              autoFocus
            />
          </div>
          <button 
            type="submit"
            className="w-full bg-rose-600 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-rose-700 transition-all shadow-xl shadow-rose-500/20 active:scale-95"
          >
            Verify & Secure Account <ArrowRight className="w-4 h-4" />
          </button>
          
          <div className="text-center space-y-4">
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">
              Didn't receive SMS? <button type="button" onClick={handleResend} className="text-rose-600 hover:underline">Resend OTP</button>
            </p>
            <p className="text-[9px] text-gray-300 font-medium leading-tight">
              NOTE: Actual SMS gateway integration is available in the production version. For this demo, please use the on-screen code.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default OTPModal;
