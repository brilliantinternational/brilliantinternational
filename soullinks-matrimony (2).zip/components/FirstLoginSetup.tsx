
import React, { useState } from 'react';
import { ShieldAlert, Save } from 'lucide-react';

interface FirstLoginSetupProps {
  onComplete: (user: string, pass: string) => void;
}

const FirstLoginSetup: React.FC<FirstLoginSetupProps> = ({ onComplete }) => {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [confirmP, setConfirmP] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (p !== confirmP) return alert("Passwords do not match");
    if (p.length < 8) return alert("Password must be at least 8 characters");
    onComplete(u, p);
  };

  return (
    <div className="fixed inset-0 z-[300] bg-gray-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-[3rem] p-12 max-w-lg w-full shadow-2xl space-y-8">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-amber-100 rounded-3xl flex items-center justify-center mx-auto rotate-3 shadow-lg">
            <ShieldAlert className="w-10 h-10 text-amber-600" />
          </div>
          <h1 className="text-3xl font-black text-gray-900">Security Update Required</h1>
          <p className="text-gray-500">This is your first login. For security, you MUST change the default administrator credentials before proceeding.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">New Super Admin Username</label>
              <input type="text" required value={u} onChange={e => setU(e.target.value)} className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500" placeholder="e.g. MasterAdmin_2025" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">New Secure Password</label>
              <input type="password" required value={p} onChange={e => setP(e.target.value)} className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500" placeholder="••••••••" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Confirm Password</label>
              <input type="password" required value={confirmP} onChange={e => setConfirmP(e.target.value)} className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500" placeholder="••••••••" />
            </div>
          </div>
          <button type="submit" className="w-full bg-amber-600 text-white font-black py-5 rounded-[1.5rem] shadow-xl shadow-amber-500/30 hover:bg-amber-700 flex items-center justify-center gap-3">
            <Save className="w-5 h-5" />
            Update Credentials & Unlock
          </button>
        </form>
      </div>
    </div>
  );
};

export default FirstLoginSetup;
