
export const RELIGIONS = [
  { id: 1, name: 'Hindu' },
  { id: 2, name: 'Muslim' },
  { id: 3, name: 'Christian' },
  { id: 4, name: 'SC/ST' }
];

export const CASTES: Record<number, string[]> = {
  1: [ // Hindu
    'Nair', 'Namboothiri', 'Brahmin', 'Iyer', 'Iyengar', 'Kshatriya', 'Ezhava', 'Thiyya', 'Billava',
    'Viswakarma (Asari, Moosari, Thattan, Kammalar)', 'Dheevara', 'Araya', 'Mukkuva',
    'Vaniya', 'Chekavar', 'Veluthedathu Nair', 'Mannan', 'Kaniyan', 'Kurup', 'Chakkala',
    'Kusavan (Potter)', 'Ulladan', 'Valan'
  ],
  4: [ // SC/ST
    'Pulaya', 'Paraya', 'Cheramar', 'Vettuvan', 'Kanakkan', 'Thandan', 'Madiga', 'Sambava',
    'Paniyan', 'Kurichiyan', 'Kurumar', 'Adiya', 'Kattunayakan', 'Irula', 'Malayarayan'
  ],
  2: [ // Muslim
    'Sunni', 'Mujahid', 'Jamath-e-Islami', 'Shafi', 'Thangal', 'Mapila (Mappila)'
  ],
  3: [ // Christian
    'Syrian Catholic', 'Syro-Malabar', 'Syro-Malankara', 'Latin Catholic',
    'Jacobite', 'Orthodox', 'Marthoma', 'CSI'
  ]
};

export const EDUCATION_LEVELS = [
  '8th Standard', '9th Standard', '10th Standard', '11th Standard', '12th Standard',
  'Diploma', 'ITI', 'B.A', 'B.Sc', 'B.Com', 'B.Tech / B.E', 'M.A', 'M.Sc', 'M.Com',
  'M.Tech', 'MBA', 'PhD', 'Others'
];

export const EDUCATION_SUBJECTS = [
  'Electronics', 'Physics', 'Chemistry', 'Maths', 'Computer Science', 'Commerce',
  'Mechanical', 'Civil', 'Electrical', 'Biology', 'History', 'Psychology', 'Nursing'
];

export const OCCUPATIONS = [
  'Software Engineer', 'IT Professional', 'Network Engineer', 'Data Scientist',
  'Doctor (MBBS)', 'Doctor (Specialist)', 'Dentist', 'Ayurvedic Doctor', 'Homeopathic Doctor',
  'Staff Nurse', 'Nurse (Gulf)', 'Head Nurse', 'Lab Technician', 'Pharmacist', 'Physiotherapist',
  'Chartered Accountant', 'Accountant', 'Banking Professional', 'Investment Banker',
  'Teacher (Primary)', 'Teacher (High School)', 'Lecturer', 'Professor', 'Principal',
  'Civil Engineer', 'Mechanical Engineer', 'Electrical Engineer', 'Architect', 'Interior Designer',
  'Government Employee (Central)', 'Government Employee (State)', 'Police Officer', 'Defense Personnel',
  'Railway Employee', 'Post Office Staff', 'Village Office Staff',
  'Business Owner', 'Entrepreneur', 'Retail Shop Owner', 'Wholesale Merchant',
  'Sales Executive', 'Marketing Manager', 'Digital Marketer',
  'Chef', 'Hotel Management Professional', 'Waitstaff',
  'Driver (Heavy)', 'Driver (Light)', 'Pilot', 'Cabin Crew', 'Ship Crew (Merchant Navy)',
  'Electrician', 'Plumber', 'Carpenter', 'Mason', 'Welder', 'Electronics Technician',
  'Agriculture / Farmer', 'Daily Wage Worker', 'Coolie',
  'Gulf Job (General)', 'Gulf Job (Technical)', 'European Country Job',
  'Lawyer', 'Journalist', 'Artist', 'Photographer', 'Videographer',
  'Student / Studying', 'Looking for Job', 'Retired', 'House Wife / Home Maker', 'Others'
];

export const BODY_TYPES = [
  'Athletic', 'Slim', 'Average', 'Heavy', 'Physically Fit', 'Differently Abled', 'Others'
];

export const DISTRICTS = [
  'Thiruvananthapuram', 'Kollam', 'Pathanamthitta', 'Alappuzha', 'Kottayam', 'Idukki',
  'Ernakulam', 'Thrissur', 'Palakkad', 'Malappuram', 'Kozhikode', 'Wayanad', 'Kannur', 'Kasaragod'
];

export const STATES = [
  'Kerala', 'Tamil Nadu', 'Karnataka', 'Andhra Pradesh', 'Telangana', 'Maharashtra', 'Delhi', 'Gujarat', 'Punjab', 'Rajasthan', 'Others'
];

export const COUNTRIES = [
  'India', 'UAE', 'Qatar', 'Oman', 'Saudi Arabia', 'Kuwait', 'Bahrain', 'UK', 'USA', 'Canada', 'Australia', 'Germany', 'Others'
];

export const ADMIN_PHONE = "6352692909";
export const SUPPORT_EMAIL = "brilliantinternational7777@gmail.com";

export const DEFAULT_ADMIN_USERNAME = "admin";
export const DEFAULT_ADMIN_PASSWORD = "admin123";
