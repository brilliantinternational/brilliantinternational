
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { UserState, Profile, Gender, MaritalStatus, Staff, ActivityLog } from './types';
import { DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_PASSWORD } from './constants';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Matches from './pages/Matches';
import ProfilePage from './pages/ProfilePage';
import AdminDashboard from './pages/AdminDashboard';
import StaffDashboard from './pages/StaffDashboard';
import AdminLogin from './pages/AdminLogin';
import OTPModal from './components/OTPModal';
import FirstLoginSetup from './components/FirstLoginSetup';
import ForgotPasswordModal from './components/ForgotPasswordModal';
import { createLog, getClientIP, isMobileDevice } from './utils';

// Added missing Profile properties to fix type error on line 21
const INITIAL_PROFILES: Profile[] = [
  {
    id: "Anu_45231",
    phone: "9876543210",
    firstName: "Anu",
    lastName: "Kurian",
    nickname: "Anu",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 26,
    height: 165,
    religionId: 3,
    casteId: 3,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "B.Tech / B.E",
    occupation: "Software Engineer",
    fatherName: "Varghese",
    fatherOccupation: "Retired",
    motherName: "Mary",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Average",
    preferredHeightMin: 140,
    preferredHeightMax: 190,
    preferredReligions: [3],
    preferredCastes: { 3: [0] }, 
    preferredDistricts: ["Ernakulam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Ernakulam",
    bio: "Looking for a God-fearing person.",
    photoUrl: "https://picsum.photos/seed/anu/400/600",
    isVerified: true,
    isDisabled: false
  }
];

const App: React.FC = () => {
  const [state, setState] = useState<UserState>(() => {
    const saved = localStorage.getItem('soul_links_state_v3');
    if (saved) return JSON.parse(saved);
    return {
      currentUser: null,
      currentStaff: null,
      isSuperAdmin: false,
      profiles: INITIAL_PROFILES,
      staff: [],
      logs: [],
      security: {
        adminUsername: DEFAULT_ADMIN_USERNAME,
        adminPasswordHash: DEFAULT_ADMIN_PASSWORD,
        isFirstLogin: true,
        allowedStaffIPs: [],
        blockedUserIPs: []
      }
    };
  });

  const [otpTarget, setOtpTarget] = useState<{ role: 'user' | 'staff' | 'admin', payload: any, type: 'register' | 'login' | 'reset' } | null>(null);
  const [showSetup, setShowSetup] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  useEffect(() => {
    localStorage.setItem('soul_links_state_v3', JSON.stringify(state));
  }, [state]);

  const handleLoginAttempt = (phone: string, password?: string) => {
    const userIP = getClientIP();
    if (state.security.blockedUserIPs.includes(userIP)) {
      alert("Access Denied: Your IP is blocked.");
      return;
    }

    const user = state.profiles.find(p => p.phone === phone);
    if (user && user.password === password) {
      setState(prev => ({ 
        ...prev, 
        currentUser: { ...user, lastLoginIP: userIP }, 
        isSuperAdmin: false, 
        currentStaff: null 
      }));
    } else {
      alert("Invalid phone number or password.");
    }
  };

  const handleStaffLoginAttempt = (phone: string, password?: string) => {
    if (!isMobileDevice()) {
      alert("Access Denied: Staff login permitted on mobile devices only.");
      return;
    }

    const staffMember = state.staff.find(s => s.phone === phone && s.isActive);
    if (!staffMember || staffMember.password !== password) {
      alert("Invalid staff phone number or password.");
      return;
    }

    const currentIP = getClientIP();
    if (state.security.allowedStaffIPs.length > 0 && !state.security.allowedStaffIPs.includes(currentIP)) {
      alert("Access Denied: Your IP is not authorized for staff access.");
      return;
    }

    const log = createLog(staffMember.id, "Staff Login Success");
    setState(prev => ({ 
      ...prev, 
      currentStaff: staffMember, 
      isSuperAdmin: false, 
      currentUser: null,
      logs: [log, ...prev.logs]
    }));
  };

  const handleAdminLoginAttempt = (username: string, pass: string) => {
    if (username === state.security.adminUsername && pass === state.security.adminPasswordHash) {
      if (state.security.isFirstLogin) {
        setShowSetup(true);
      } else {
        setState(prev => ({ ...prev, isSuperAdmin: true, currentUser: null, currentStaff: null }));
      }
    } else {
      alert("Invalid Admin Credentials");
    }
  };

  const onRegisterAttempt = (profile: Profile) => {
    setOtpTarget({ role: 'user', payload: profile, type: 'register' });
  };

  const onOTPSuccess = () => {
    if (!otpTarget) return;

    if (otpTarget.type === 'register') {
      const profile = otpTarget.payload as Profile;
      const existing = state.profiles.find(p => p.phone === profile.phone);
      
      if (existing) {
        const updatedProfiles = state.profiles.map(p => 
          p.phone === profile.phone ? { ...profile, id: existing.id } : p
        );
        setState(prev => ({
          ...prev,
          profiles: updatedProfiles,
          currentUser: { ...profile, id: existing.id }
        }));
      } else {
        setState(prev => ({
          ...prev,
          profiles: [...prev.profiles, profile],
          currentUser: profile
        }));
      }
    }
    setOtpTarget(null);
  };

  const handleResetPassword = (phone: string, newPassword: string) => {
    const user = state.profiles.find(p => p.phone === phone);
    const staffMember = state.staff.find(s => s.phone === phone);

    if (user) {
      setState(prev => ({
        ...prev,
        profiles: prev.profiles.map(p => p.phone === phone ? { ...p, password: newPassword } : p)
      }));
      alert("User password updated successfully.");
    } else if (staffMember) {
      setState(prev => ({
        ...prev,
        staff: prev.staff.map(s => s.phone === phone ? { ...s, password: newPassword } : s)
      }));
      alert("Staff password updated successfully.");
    } else {
      alert("Phone number not found.");
    }
  };

  const updateAdminConfig = (newUsername: string, newPass: string) => {
    setState(prev => ({
      ...prev,
      isSuperAdmin: true,
      security: {
        ...prev.security,
        adminUsername: newUsername,
        adminPasswordHash: newPass,
        isFirstLogin: false
      }
    }));
    setShowSetup(false);
  };

  const logout = () => {
    if (state.currentStaff) {
      const log = createLog(state.currentStaff.id, "Staff Logout");
      setState(prev => ({ ...prev, logs: [log, ...prev.logs] }));
    }
    setState(prev => ({ ...prev, currentUser: null, currentStaff: null, isSuperAdmin: false }));
  };

  const addLog = (action: string) => {
    if (state.currentStaff) {
      const log = createLog(state.currentStaff.id, action);
      setState(prev => ({ ...prev, logs: [log, ...prev.logs] }));
    }
  };

  return (
    <Router>
      <Layout 
        currentUser={state.currentUser} 
        currentStaff={state.currentStaff} 
        isSuperAdmin={state.isSuperAdmin} 
        onLogout={logout}
      >
        <Routes>
          <Route path="/" element={<Home currentUser={state.currentUser} profiles={state.profiles} />} />
          <Route path="/login" element={<Login 
            onLoginAttempt={handleLoginAttempt} 
            onStaffLoginAttempt={handleStaffLoginAttempt}
            onForgotPassword={() => setShowForgotPassword(true)}
          />} />
          <Route path="/register" element={<Register onRegister={onRegisterAttempt} profiles={state.profiles} />} />
          <Route path="/matches" element={state.currentUser || state.currentStaff || state.isSuperAdmin ? <Matches currentUser={state.currentUser} profiles={state.profiles} staffView={!!state.currentStaff || state.isSuperAdmin} onAction={addLog} /> : <Navigate to="/login" />} />
          <Route path="/profile" element={state.currentUser ? <ProfilePage user={state.currentUser} onUpdate={(u) => setState(prev => ({ ...prev, profiles: prev.profiles.map(p => p.phone === u.phone ? u : p), currentUser: u }))} /> : <Navigate to="/login" />} />
          <Route path="/admin" element={state.isSuperAdmin ? <AdminDashboard state={state} setState={setState} /> : <Navigate to="/admin-login" />} />
          <Route path="/staff" element={state.currentStaff ? <StaffDashboard staff={state.currentStaff} profiles={state.profiles} onAction={addLog} /> : <Navigate to="/login" />} />
          <Route path="/admin-login" element={<AdminLogin onLogin={handleAdminLoginAttempt} />} />
        </Routes>
      </Layout>

      {otpTarget && (
        <OTPModal 
          onVerify={onOTPSuccess} 
          onCancel={() => setOtpTarget(null)} 
          target={otpTarget.payload.phone || 'Account'} 
        />
      )}
      {showSetup && <FirstLoginSetup onComplete={updateAdminConfig} />}
      {showForgotPassword && <ForgotPasswordModal 
        onClose={() => setShowForgotPassword(false)} 
        onReset={handleResetPassword} 
        profiles={state.profiles}
        staff={state.staff}
      />}
    </Router>
  );
};

export default App;
