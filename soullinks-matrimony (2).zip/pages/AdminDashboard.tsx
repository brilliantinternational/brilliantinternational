
import React, { useState } from 'react';
import { UserState, Profile, Staff } from '../types';
import { RELIGIONS, CASTES, DISTRICTS } from '../constants';
import { exportToExcel } from '../utils';
import { ShieldCheck, Download, Users, UserPlus, ListTodo, Globe, Trash2, ShieldAlert } from 'lucide-react';

interface AdminDashboardProps {
  state: UserState;
  setState: React.Dispatch<React.SetStateAction<UserState>>;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ state, setState }) => {
  const [tab, setTab] = useState<'profiles' | 'staff' | 'logs' | 'security'>('profiles');
  const [newStaffPhone, setNewStaffPhone] = useState('');
  const [newStaffName, setNewStaffName] = useState('');

  const handleAddStaff = (e: React.FormEvent) => {
    e.preventDefault();
    // Fix: Added the required 'password' property to the new Staff object.
    // For demo purposes, we default the password to 'staff123' if not otherwise provided in a UI field.
    const newS: Staff = {
      id: `staff_${Date.now()}`,
      phone: newStaffPhone,
      name: newStaffName,
      password: 'staff123',
      isActive: true
    };
    setState(prev => ({ ...prev, staff: [...prev.staff, newS] }));
    setNewStaffPhone('');
    setNewStaffName('');
  };

  const removeStaff = (id: string) => {
    setState(prev => ({ ...prev, staff: prev.staff.filter(s => s.id !== id) }));
  };

  const addAllowedIP = (ip: string) => {
    if (!ip) return;
    setState(prev => ({ 
      ...prev, 
      security: { ...prev.security, allowedStaffIPs: [...prev.security.allowedStaffIPs, ip] } 
    }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex justify-between items-center bg-gray-900 p-8 rounded-[3rem] text-white shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-rose-500 rounded-3xl flex items-center justify-center shadow-lg shadow-rose-500/20">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-black">Super Admin Console</h1>
            <p className="opacity-60 text-sm">Welcome back, {state.security.adminUsername}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {['profiles', 'staff', 'logs', 'security'].map((t) => (
            <button 
              key={t}
              onClick={() => setTab(t as any)}
              className={`px-6 py-3 rounded-2xl font-bold transition-all capitalize ${tab === t ? 'bg-white text-gray-900 shadow-xl' : 'hover:bg-white/10'}`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {tab === 'profiles' && (
        <div className="bg-white rounded-[3rem] border border-gray-100 shadow-xl overflow-hidden animate-in fade-in duration-500">
           <div className="p-8 border-b border-gray-50 flex justify-between items-center">
             <h3 className="text-2xl font-black text-gray-900 flex items-center gap-2">
               <Users className="text-rose-500" /> User Directory
             </h3>
             <button onClick={() => exportToExcel(state.profiles, 'Full_Database')} className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold">
               <Download className="w-4 h-4" /> Export All
             </button>
           </div>
           <div className="p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {state.profiles.map(p => (
               <div key={p.id} className="p-6 border border-gray-50 rounded-3xl hover:shadow-lg transition-all space-y-4">
                  <div className="flex items-center gap-4">
                    <img src={p.photoUrl} className="w-14 h-14 rounded-2xl object-cover" />
                    <div>
                      <h4 className="font-black text-gray-900">{p.nickname}</h4>
                      <p className="text-xs text-rose-500 font-bold">{p.id}</p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 font-mono font-bold bg-emerald-50 text-emerald-700 p-3 rounded-xl flex justify-between items-center">
                    <span>{p.phone}</span>
                    <Globe className="w-4 h-4" />
                  </div>
               </div>
             ))}
           </div>
        </div>
      )}

      {tab === 'staff' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in slide-in-from-right duration-500">
          <div className="lg:col-span-1 bg-white p-8 rounded-[3rem] border border-gray-100 shadow-xl h-fit">
            <h3 className="text-xl font-black mb-6 flex items-center gap-2"><UserPlus className="text-rose-500" /> Create Staff</h3>
            <form onSubmit={handleAddStaff} className="space-y-4">
              <input 
                type="text" placeholder="Staff Name" required value={newStaffName} onChange={e => setNewStaffName(e.target.value)}
                className="w-full p-4 bg-gray-50 rounded-2xl border-none outline-none focus:ring-2 focus:ring-rose-500"
              />
              <input 
                type="tel" placeholder="Staff Phone" required value={newStaffPhone} onChange={e => setNewStaffPhone(e.target.value)}
                className="w-full p-4 bg-gray-50 rounded-2xl border-none outline-none focus:ring-2 focus:ring-rose-500"
              />
              <button type="submit" className="w-full py-4 bg-rose-600 text-white font-black rounded-2xl shadow-lg hover:bg-rose-700">Add Staff Account</button>
            </form>
          </div>
          <div className="lg:col-span-2 bg-white rounded-[3rem] border border-gray-100 shadow-xl overflow-hidden">
             <div className="p-8 border-b border-gray-50"><h3 className="text-xl font-black">Active Staff Team</h3></div>
             <div className="p-8 space-y-4">
               {state.staff.map(s => (
                 <div key={s.id} className="flex justify-between items-center p-6 bg-gray-50 rounded-3xl">
                   <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-gray-900 text-white rounded-full flex items-center justify-center font-black">{s.name[0]}</div>
                     <div>
                       <div className="font-black text-gray-900">{s.name}</div>
                       <div className="text-xs text-gray-400">{s.phone}</div>
                     </div>
                   </div>
                   <button onClick={() => removeStaff(s.id)} className="p-3 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors"><Trash2 className="w-5 h-5" /></button>
                 </div>
               ))}
               {state.staff.length === 0 && <div className="text-center py-12 text-gray-400 italic">No staff members created yet.</div>}
             </div>
          </div>
        </div>
      )}

      {tab === 'logs' && (
        <div className="bg-white rounded-[3rem] border border-gray-100 shadow-xl overflow-hidden animate-in slide-in-from-bottom duration-500">
           <div className="p-8 border-b border-gray-50 flex justify-between items-center">
             <h3 className="text-2xl font-black text-gray-900 flex items-center gap-2"><ListTodo className="text-rose-500" /> Activity Audit Logs</h3>
             <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Read Only System Log</span>
           </div>
           <div className="max-h-[600px] overflow-y-auto">
             <table className="w-full text-left">
               <thead className="bg-gray-50">
                 <tr>
                   <th className="px-8 py-4 text-xs font-black text-gray-400 uppercase">Staff ID</th>
                   <th className="px-8 py-4 text-xs font-black text-gray-400 uppercase">Action</th>
                   <th className="px-8 py-4 text-xs font-black text-gray-400 uppercase">Timestamp</th>
                   <th className="px-8 py-4 text-xs font-black text-gray-400 uppercase">IP Address</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-gray-50">
                 {state.logs.map(l => (
                   <tr key={l.id} className="hover:bg-gray-50 transition-colors">
                     <td className="px-8 py-6 font-bold text-gray-900">{state.staff.find(s => s.id === l.staffId)?.name || 'Unknown'}</td>
                     <td className="px-8 py-6 text-rose-600 font-bold">{l.action}</td>
                     <td className="px-8 py-6 text-sm text-gray-500">{new Date(l.timestamp).toLocaleString()}</td>
                     <td className="px-8 py-6 font-mono text-xs text-emerald-600">{l.ip}</td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>
      )}

      {tab === 'security' && (
        <div className="bg-white p-12 rounded-[3rem] border border-gray-100 shadow-xl animate-in zoom-in duration-500 space-y-12">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
             <div className="space-y-6">
                <h3 className="text-2xl font-black text-gray-900 flex items-center gap-2"><Globe className="text-emerald-500" /> IP Whitelisting</h3>
                <p className="text-gray-500 text-sm">Restrict staff login to specific static IP addresses. If empty, all IPs are allowed.</p>
                <div className="flex gap-2">
                  <input id="new-ip" type="text" placeholder="e.g. 192.168.1.50" className="flex-1 p-4 bg-gray-50 rounded-2xl border-none outline-none focus:ring-2 focus:ring-emerald-500" />
                  <button onClick={() => addAllowedIP((document.getElementById('new-ip') as HTMLInputElement).value)} className="px-6 py-4 bg-emerald-600 text-white font-black rounded-2xl">Add IP</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {state.security.allowedStaffIPs.map(ip => (
                    <span key={ip} className="px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold border border-emerald-100 flex items-center gap-2">
                      {ip}
                      <button onClick={() => setState(p => ({ ...p, security: { ...p.security, allowedStaffIPs: p.security.allowedStaffIPs.filter(i => i !== ip) } }))} className="hover:text-rose-500"><Trash2 className="w-3 h-3" /></button>
                    </span>
                  ))}
                </div>
             </div>

             <div className="space-y-6">
                <h3 className="text-2xl font-black text-gray-900 flex items-center gap-2"><ShieldAlert className="text-rose-500" /> System Lockdown</h3>
                <div className="p-8 bg-rose-50 rounded-[2rem] border border-rose-100 space-y-4">
                  <h4 className="font-black text-rose-900">Current Security Profile</h4>
                  <ul className="text-sm text-rose-800 space-y-2 font-medium">
                    <li>• Super Admin Username: <b>{state.security.adminUsername}</b></li>
                    <li>• First Login Setup: <span className={state.security.isFirstLogin ? 'text-rose-500' : 'text-emerald-500'}>{state.security.isFirstLogin ? 'Pending' : 'Completed'}</span></li>
                    <li>• Password Encryption: <b>AES-256 Mock</b></li>
                  </ul>
                </div>
             </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
