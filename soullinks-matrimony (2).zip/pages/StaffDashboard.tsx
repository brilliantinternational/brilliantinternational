
import React, { useState } from 'react';
import { Staff, Profile } from '../types';
import { RELIGIONS, CASTES, DISTRICTS } from '../constants';
import { exportToExcel } from '../utils';
import { Search, Download, Users, Phone, Shield } from 'lucide-react';

interface StaffDashboardProps {
  staff: Staff;
  profiles: Profile[];
  onAction: (action: string) => void;
}

const StaffDashboard: React.FC<StaffDashboardProps> = ({ staff, profiles, onAction }) => {
  const [search, setSearch] = useState('');

  const filtered = profiles.filter(p => 
    p.id.toLowerCase().includes(search.toLowerCase()) || 
    p.phone.includes(search)
  );

  const handleExport = () => {
    onAction("Bulk Excel Export");
    exportToExcel(filtered, `Staff_Export_${Date.now()}`);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="bg-rose-600 rounded-3xl p-8 text-white shadow-xl flex flex-col items-center text-center space-y-3">
        <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
          <Shield className="w-10 h-10" />
        </div>
        <div>
          <h1 className="text-2xl font-black">Staff Control: {staff.name}</h1>
          <p className="opacity-80 text-sm">Secure Portal • Mobile Authenticated</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search by ID or Phone..."
            className="w-full pl-12 pr-4 py-4 bg-gray-50 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button onClick={handleExport} className="w-full flex items-center justify-center gap-2 py-4 bg-emerald-600 text-white font-bold rounded-2xl shadow-lg hover:bg-emerald-700">
          <Download className="w-5 h-5" />
          Export Visible to Excel
        </button>
      </div>

      <div className="space-y-4">
        <h2 className="text-lg font-bold text-gray-900 px-2 flex items-center gap-2">
          <Users className="w-5 h-5 text-rose-500" />
          User Records ({filtered.length})
        </h2>
        {filtered.map(p => (
          <div key={p.id} className="bg-white p-6 rounded-3xl border border-gray-100 flex justify-between items-center shadow-sm">
            <div className="flex items-center gap-4">
              <img src={p.photoUrl} className="w-12 h-12 rounded-xl object-cover" />
              <div>
                <div className="font-bold text-gray-900">{p.nickname}</div>
                <div className="text-xs text-rose-600 font-bold">{p.id}</div>
              </div>
            </div>
            <div className="text-right">
              <a href={`tel:${p.phone}`} className="flex items-center gap-1 text-emerald-600 font-mono font-bold hover:underline" onClick={() => onAction(`View Phone: ${p.id}`)}>
                <Phone className="w-4 h-4" />
                {p.phone}
              </a>
              <div className="text-[10px] text-gray-400 uppercase tracking-tighter">{p.district}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StaffDashboard;
