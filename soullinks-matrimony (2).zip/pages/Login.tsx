
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Heart, Phone, ArrowRight, ShieldCheck, User, Lock, Eye, EyeOff } from 'lucide-react';

interface LoginProps {
  onLoginAttempt: (phone: string, password?: string) => void;
  onStaffLoginAttempt: (phone: string, password?: string) => void;
  onForgotPassword: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginAttempt, onStaffLoginAttempt, onForgotPassword }) => {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [userType, setUserType] = useState<'user' | 'staff'>('user');

  const handleDirectLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) {
      alert("Please enter a valid phone number");
      return;
    }
    if (userType === 'user') {
      onLoginAttempt(phoneNumber, password);
    } else {
      onStaffLoginAttempt(phoneNumber, password);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white p-8 md:p-12 rounded-[3rem] shadow-2xl border border-gray-100 w-full max-w-md space-y-8 animate-in fade-in zoom-in duration-500">
        
        <div className="flex p-1 bg-gray-100 rounded-2xl mb-4">
          <button 
            type="button"
            onClick={() => setUserType('user')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold transition-all ${userType === 'user' ? 'bg-white shadow-md text-rose-600' : 'text-gray-400'}`}
          >
            <User className="w-4 h-4" /> User
          </button>
          <button 
            type="button"
            onClick={() => setUserType('staff')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold transition-all ${userType === 'staff' ? 'bg-white shadow-md text-rose-600' : 'text-gray-400'}`}
          >
            <ShieldCheck className="w-4 h-4" /> Staff
          </button>
        </div>

        <div className="text-center space-y-2">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto shadow-lg rotate-12 mb-6 transition-colors duration-500 ${userType === 'user' ? 'bg-rose-600' : 'bg-gray-900'}`}>
            <Heart className="w-8 h-8 text-white fill-white" />
          </div>
          <h1 className="text-3xl font-black text-gray-900">{userType === 'user' ? 'Welcome Back' : 'Staff Portal'}</h1>
          <p className="text-gray-500 text-sm">Login with phone and password</p>
        </div>

        <form onSubmit={handleDirectLogin} className="space-y-6">
          <div className="space-y-4">
            <div className="relative group">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
              <input
                type="tel"
                placeholder="Phone Number"
                required
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold text-gray-900"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />
            </div>
            
            <div className="relative group">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                required
                className="w-full pl-12 pr-12 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold text-gray-900"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button 
                type="button" 
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-rose-600 transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <button 
              type="button" 
              onClick={onForgotPassword}
              className="text-sm font-bold text-rose-600 hover:underline"
            >
              Forgot Password?
            </button>
            <Link to="/register" className="text-sm font-bold text-gray-400 hover:text-rose-600 transition-colors">
              New user? <span className="text-rose-600 font-black">Join Free</span>
            </Link>
          </div>

          <button
            type="submit"
            className="w-full bg-rose-600 text-white py-5 rounded-2xl font-black text-lg hover:bg-rose-700 transition shadow-xl shadow-rose-500/20 flex items-center justify-center gap-2 active:scale-95"
          >
            Log In Securely <ArrowRight className="w-5 h-5" />
          </button>
        </form>

        <div className="text-center pt-4">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest leading-relaxed">
            By logging in you agree to our strictly non-dating matrimony policy.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
