
import React, { useState } from 'react';
import { Profile, Sibling } from '../types';
import { DISTRICTS, EDUCATION_LEVELS, EDUCATION_SUBJECTS, BODY_TYPES, RELIGIONS, CASTES, OCCUPATIONS, STATES, COUNTRIES } from '../constants';
import { applyWatermark } from '../utils';
import { 
  Camera, Save, User, Shield, Info, CheckCircle, Smartphone, 
  GraduationCap, Users, Stethoscope, Lock, Loader2, FileText, 
  Briefcase, Plus, Trash2, Globe, MessageSquare 
} from 'lucide-react';

interface ProfilePageProps {
  user: Profile;
  onUpdate: (updated: Profile) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, onUpdate }) => {
  const [formData, setFormData] = useState<any>({ ...user });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLoading(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        const watermarked = await applyWatermark(reader.result as string);
        setFormData((prev: any) => ({ ...prev, photoUrl: watermarked }));
        setLoading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleCastePreference = (religionId: number, casteIndex: number) => {
    setFormData((prev: any) => {
      const current = prev.preferredCastes[religionId] || [];
      let updated;
      if (casteIndex === 0) {
        updated = current.includes(0) ? [] : [0];
      } else {
        updated = current.includes(casteIndex)
          ? current.filter((v: any) => v !== casteIndex)
          : [...current.filter((v: any) => v !== 0), casteIndex];
      }
      return { ...prev, preferredCastes: { ...prev.preferredCastes, [religionId]: updated } };
    });
  };

  const togglePreference = (key: string, value: any) => {
    setFormData((prev: any) => {
      const current = prev[key] || [];
      const updated = current.includes(value) ? current.filter((v: any) => v !== value) : [...current, value];
      return { ...prev, [key]: updated };
    });
  };

  const handleSave = () => {
    if (!formData.firstName || !formData.lastName || !formData.nickname) {
      alert("Name fields are mandatory.");
      return;
    }
    onUpdate(formData);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
  };

  const addSibling = () => {
    const newSib: Sibling = { id: Date.now().toString(), type: 'Brother', status: 'Unmarried' };
    setFormData((prev: any) => ({ ...prev, siblings: [...prev.siblings, newSib] }));
  };

  const updateSibling = (id: string, field: keyof Sibling, value: string) => {
    setFormData((prev: any) => ({
      ...prev,
      siblings: prev.siblings.map((s: Sibling) => s.id === id ? { ...s, [field]: value } : s)
    }));
  };

  const removeSibling = (id: string) => {
    setFormData((prev: any) => ({ ...prev, siblings: prev.siblings.filter((s: Sibling) => s.id !== id) }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData((prev: any) => ({ ...prev, [name]: finalValue }));
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 space-y-8">
      <div className="bg-white rounded-[3rem] shadow-xl overflow-hidden border border-gray-100">
        <div className="relative h-64 bg-rose-600">
          <div className="absolute inset-0 overflow-hidden opacity-30 blur-3xl">
             <img src={formData.photoUrl} className="w-full h-full object-cover" />
          </div>
          <div className="absolute -bottom-16 left-12">
            <div className="relative group w-40 h-40">
              <img src={formData.photoUrl} className="w-full h-full rounded-[2.5rem] border-8 border-white object-cover shadow-2xl" />
              <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer rounded-[2.5rem]">
                <Camera className="text-white w-8 h-8" />
                <input type="file" className="hidden" onChange={handlePhotoUpload} />
              </label>
              {loading && <div className="absolute inset-0 bg-white/60 flex items-center justify-center rounded-[2.5rem]"><Loader2 className="animate-spin text-rose-600" /></div>}
            </div>
          </div>
        </div>

        <div className="pt-24 px-12 pb-12">
          <div className="flex justify-between items-start mb-12">
            <div>
              <h1 className="text-4xl font-black text-gray-900 tracking-tighter">{formData.nickname}</h1>
              <p className="text-rose-600 font-bold uppercase tracking-widest text-sm">{formData.id}</p>
            </div>
            <button onClick={handleSave} className="px-8 py-4 bg-rose-600 text-white font-black rounded-2xl shadow-xl flex items-center gap-2 active:scale-95 transition-all">
              <Save className="w-5 h-5" /> Save Changes
            </button>
          </div>

          {success && (
            <div className="mb-12 p-4 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center gap-3 font-bold border border-emerald-100">
              <CheckCircle className="w-6 h-6" /> Profile updated successfully.
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-12">
              <section className="space-y-6">
                <h3 className="flex items-center gap-3 text-xl font-black text-gray-900 uppercase tracking-tight"><User className="w-6 h-6 text-rose-500" /> Identity Matrix</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">First Name *</label>
                    <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl font-bold border-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Nickname *</label>
                    <input type="text" name="nickname" value={formData.nickname} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl font-bold border-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Occupation</label>
                    <select name="occupation" value={formData.occupation} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl font-bold border-none">
                      {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  {formData.occupation === 'Others' && (
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Job Details box</label>
                      <input type="text" name="occupationOthers" value={formData.occupationOthers} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl font-bold" />
                    </div>
                  )}
                  <div className="col-span-2 space-y-1">
                    <label className="text-[10px] font-black text-blue-500 uppercase tracking-widest ml-1">Self Extra Details Box</label>
                    <textarea name="additionalDetails" value={formData.additionalDetails} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl h-24 font-bold border-none" />
                  </div>
                </div>
              </section>

              <section className="space-y-6">
                <h3 className="flex items-center gap-3 text-xl font-black text-gray-900 uppercase tracking-tight"><MessageSquare className="w-6 h-6 text-blue-500" /> Partner Preference Remarks</h3>
                <textarea name="preferenceRemarks" value={formData.preferenceRemarks} onChange={handleChange} className="w-full p-6 bg-blue-50/50 rounded-3xl h-48 font-bold border-none outline-none focus:ring-2 focus:ring-blue-500" placeholder="Type your detailed partner preferences here..." />
              </section>
            </div>

            <div className="space-y-12">
              <section className="space-y-6">
                <h3 className="flex items-center gap-3 text-xl font-black text-gray-900 uppercase tracking-tight"><Lock className="w-6 h-6 text-blue-500" /> System Preferences</h3>
                <div className="p-8 bg-blue-50 border border-blue-100 rounded-[2.5rem] space-y-6">
                   <div className="space-y-2">
                     <label className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Target Occupations</label>
                     <div className="flex flex-wrap gap-1 max-h-40 overflow-y-auto p-2 bg-white/50 rounded-xl">
                       {OCCUPATIONS.map(o => (
                         <button key={o} onClick={() => togglePreference('preferredOccupations', o)} className={`px-2 py-1 rounded text-[8px] font-bold ${formData.preferredOccupations.includes(o) ? 'bg-blue-600 text-white' : 'text-blue-300 border border-blue-50'}`}>{o}</button>
                       ))}
                     </div>
                     <input type="text" name="preferredOccupationOthers" placeholder="Other Job Box..." value={formData.preferredOccupationOthers} onChange={handleChange} className="w-full p-3 bg-white/50 rounded-xl text-xs font-bold border border-blue-100" />
                   </div>
                   
                   <div className="space-y-1">
                     <label className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Preferred Countries</label>
                     <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto p-2 bg-white/50 rounded-xl">
                       {COUNTRIES.map(c => (
                         <button key={c} onClick={() => togglePreference('preferredCountries', c)} className={`px-2 py-1 rounded text-[8px] font-bold ${formData.preferredCountries.includes(c) ? 'bg-blue-600 text-white' : 'text-blue-300 border border-blue-50'}`}>{c}</button>
                       ))}
                     </div>
                     <input type="text" name="preferredCountryOthers" placeholder="Other Country Box..." value={formData.preferredCountryOthers} onChange={handleChange} className="w-full p-3 bg-white/50 rounded-xl text-xs font-bold border border-blue-100" />
                   </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
