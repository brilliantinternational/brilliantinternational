
import React, { useState } from 'react';
import { ShieldCheck, Key, User } from 'lucide-react';

interface AdminLoginProps {
  onLogin: (u: string, p: string) => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin }) => {
  const [u, setU] = useState('');
  const [p, setP] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(u, p);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 p-4">
      <div className="bg-white rounded-[3rem] p-12 max-w-md w-full shadow-2xl space-y-8 animate-in slide-in-from-bottom duration-500">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-gray-900 rounded-[2rem] flex items-center justify-center mx-auto shadow-xl ring-4 ring-rose-500/20">
            <ShieldCheck className="w-10 h-10 text-rose-500" />
          </div>
          <h1 className="text-3xl font-black text-gray-900">Vault Access</h1>
          <p className="text-gray-500 text-sm">Restricted to Super Administrators only.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input type="text" required value={u} onChange={e => setU(e.target.value)} className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none" placeholder="Username" />
            </div>
            <div className="relative">
              <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input type="password" required value={p} onChange={e => setP(e.target.value)} className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none" placeholder="Master Password" />
            </div>
          </div>
          <button type="submit" className="w-full py-5 bg-gray-900 text-white font-black rounded-2xl hover:bg-black transition-all shadow-2xl flex items-center justify-center gap-2">
            Secure Auth
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
