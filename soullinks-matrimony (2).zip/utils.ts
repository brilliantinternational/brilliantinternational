
import { Profile, ActivityLog } from './types';

export async function applyWatermark(base64Image: string): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Image;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve(base64Image);
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      const fontSize = Math.floor(img.width / 15);
      ctx.font = `bold ${fontSize}px Arial`;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const text = "SoulLinks Matrimony";
      const spacing = fontSize * 5;
      for (let x = 0; x < canvas.width; x += spacing) {
        for (let y = 0; y < canvas.height; y += spacing) {
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(-Math.PI / 4);
          ctx.fillText(text, 0, 0);
          ctx.restore();
        }
      }
      resolve(canvas.toDataURL('image/jpeg', 0.8));
    };
  });
}

export function generateProfileId(nickname: string): string {
  const randomNum = Math.floor(10000 + Math.random() * 90000);
  return `${nickname}_${randomNum}`;
}

export function exportToExcel(profiles: Profile[], filename: string) {
  const data = profiles.map(p => ({
    'Profile ID': p.id,
    'Nickname': p.nickname,
    'Age': p.age,
    'Height': p.height,
    'Religion': p.religionId,
    'Caste/Denomination': p.casteId,
    'Marital Status': p.maritalStatus === 1 ? 'First' : 'Second',
    'District': p.district,
    'Phone Number': p.phone,
    'Remarks': ''
  }));

  const worksheet = (window as any).XLSX.utils.json_to_sheet(data);
  const workbook = (window as any).XLSX.utils.book_new();
  (window as any).XLSX.utils.book_append_sheet(workbook, worksheet, 'Profiles');
  (window as any).XLSX.writeFile(workbook, `${filename}.xlsx`);
}

export function getClientIP(): string {
  // Mocked for client-side demo
  return "192.168.1.1";
}

export function isMobileDevice(): boolean {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

export function createLog(staffId: string, action: string): ActivityLog {
  return {
    id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    staffId,
    action,
    timestamp: new Date().toISOString(),
    ip: getClientIP()
  };
}
