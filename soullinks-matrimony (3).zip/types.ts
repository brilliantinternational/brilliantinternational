
export enum Gender {
  MALE = 1,
  FEMALE = 2
}

export enum MaritalStatus {
  FIRST = 1,
  SECOND = 2
}

export enum UserRole {
  USER = 'user',
  STAFF = 'staff',
  SUPER_ADMIN = 'super_admin'
}

export interface Sibling {
  id: string;
  type: 'Brother' | 'Sister';
  status: 'Married' | 'Unmarried';
}

export interface ChatMessage {
  id: string;
  senderId: string; // 'admin' or profile ID
  receiverId: string; // 'admin' or profile ID
  text: string;
  timestamp: string;
}

export interface Profile {
  id: string;
  phone: string;
  firstName: string;
  lastName: string;
  nickname: string;
  password: string;
  gender: Gender;
  age: number;
  height: number;
  religionId: number;
  casteId: number;
  subCaste?: string;
  isPentecostal: boolean;
  isBrethren: boolean;
  maritalStatus: MaritalStatus;
  
  // Education & Job
  educationLevel: string;
  educationSubject?: string;
  educationOthers?: string;
  occupation: string;
  occupationOthers?: string;
  
  // Family
  fatherName: string;
  fatherOccupation: string;
  motherName: string;
  motherOccupation: string;
  siblings: Sibling[];
  
  // Health & Physical
  bodyType: string;
  healthDisclosure?: string;
  additionalDetails?: string;

  // Preferences (SYSTEM ONLY - NOT VISIBLE TO OTHERS)
  preferredHeightMin: number;
  preferredHeightMax: number;
  preferredReligions: number[];
  preferredCastes: Record<number, number[]>; 
  preferredDistricts: string[];
  preferredStates: string[];
  preferredStateOthers?: string;
  preferredCountries: string[];
  preferredCountryOthers?: string;
  preferredOccupations: string[];
  preferredOccupationOthers?: string;
  preferredPentecostal: boolean;
  preferredBrethren: boolean;
  preferenceRemarks?: string;

  country: string;
  countryOthers?: string;
  state: string;
  stateOthers?: string;
  district: string;
  bio: string;
  photoUrl: string;
  isVerified: boolean;
  isDisabled: boolean;
  isBanned?: boolean; 
  lastLoginIP?: string;
}

export interface Staff {
  id: string;
  phone: string;
  name: string;
  password: string;
  isActive: boolean;
}

export interface ActivityLog {
  id: string;
  staffId: string;
  action: string;
  timestamp: string;
  ip: string;
}

export interface SecurityConfig {
  adminUsername: string;
  adminPasswordHash: string;
  adminPin: string; // Persistent secret PIN for every login
  isFirstLogin: boolean;
  allowedStaffIPs: string[];
  blockedUserIPs: string[];
}

export interface UserState {
  currentUser: Profile | null;
  currentStaff: Staff | null;
  isSuperAdmin: boolean;
  profiles: Profile[];
  staff: Staff[];
  logs: ActivityLog[];
  messages: ChatMessage[];
  security: SecurityConfig;
}
