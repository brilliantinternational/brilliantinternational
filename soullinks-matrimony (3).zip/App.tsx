
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { UserState, Profile, Gender, MaritalStatus, Staff, ActivityLog, ChatMessage } from './types';
import { DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_PASSWORD } from './constants';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Matches from './pages/Matches';
import ProfilePage from './pages/ProfilePage';
import AdminDashboard from './pages/AdminDashboard';
import AdminRegister from './pages/AdminRegister';
import StaffDashboard from './pages/StaffDashboard';
import OTPModal from './components/OTPModal';
import ForgotPasswordModal from './components/ForgotPasswordModal';
import { createLog, getClientIP, isMobileDevice } from './utils';

const INITIAL_PROFILES: Profile[] = [
  {
    id: "Anu_45231",
    phone: "9876543210",
    firstName: "Anu",
    lastName: "Kurian",
    nickname: "Anu",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 26,
    height: 165,
    religionId: 3,
    casteId: 3,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "B.Tech / B.E",
    occupation: "Software Engineer",
    fatherName: "Varghese",
    fatherOccupation: "Retired",
    motherName: "Mary",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Average",
    preferredHeightMin: 140,
    preferredHeightMax: 190,
    preferredReligions: [3],
    preferredCastes: { 3: [0] }, 
    preferredDistricts: ["Ernakulam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Ernakulam",
    bio: "Looking for a God-fearing person.",
    photoUrl: "https://picsum.photos/seed/anu/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Rajesh_88291",
    phone: "9000000001",
    firstName: "Rajesh",
    lastName: "Kumar",
    nickname: "Rajesh",
    password: "Password@123",
    gender: Gender.MALE,
    age: 30,
    height: 175,
    religionId: 1,
    casteId: 7,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "MBA",
    occupation: "Business Owner",
    fatherName: "Sukumaran",
    fatherOccupation: "Retired",
    motherName: "Latha",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Athletic",
    preferredHeightMin: 155,
    preferredHeightMax: 170,
    preferredReligions: [1],
    preferredCastes: { 1: [0] },
    preferredDistricts: ["Alappuzha", "Kottayam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Alappuzha",
    bio: "Simple and hardworking person.",
    photoUrl: "https://picsum.photos/seed/rajesh/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Meera_56432",
    phone: "9000000002",
    firstName: "Meera",
    lastName: "Nair",
    nickname: "Meera",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 27,
    height: 160,
    religionId: 1,
    casteId: 1,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "M.Sc",
    occupation: "Teacher (High School)",
    fatherName: "Rajan",
    fatherOccupation: "Retired",
    motherName: "Sulo",
    motherOccupation: "House Wife",
    siblings: [],
    bodyType: "Average",
    preferredHeightMin: 170,
    preferredHeightMax: 185,
    preferredReligions: [1],
    preferredCastes: { 1: [1] },
    preferredDistricts: ["Thiruvananthapuram", "Kollam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Thiruvananthapuram",
    bio: "Looking for a well-settled professional.",
    photoUrl: "https://picsum.photos/seed/meera/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Anas_33214",
    phone: "9000000003",
    firstName: "Mohammed",
    lastName: "Anas",
    nickname: "Anas",
    password: "Password@123",
    gender: Gender.MALE,
    age: 28,
    height: 172,
    religionId: 2,
    casteId: 1,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "B.Tech / B.E",
    occupation: "IT Professional",
    fatherName: "Ibrahim",
    fatherOccupation: "Merchant",
    motherName: "Fathima",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Slim",
    preferredHeightMin: 155,
    preferredHeightMax: 165,
    preferredReligions: [2],
    preferredCastes: { 2: [0] },
    preferredDistricts: ["Malappuram", "Kozhikode"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Malappuram",
    bio: "Seeking a religious and family-oriented partner.",
    photoUrl: "https://picsum.photos/seed/anas/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Amina_77210",
    phone: "9000000004",
    firstName: "Amina",
    lastName: "Beevi",
    nickname: "Amina",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 24,
    height: 162,
    religionId: 2,
    casteId: 1,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "B.A",
    occupation: "Student / Studying",
    fatherName: "Haneefa",
    fatherOccupation: "Business",
    motherName: "Nabeesa",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Slim",
    preferredHeightMin: 170,
    preferredHeightMax: 180,
    preferredReligions: [2],
    preferredCastes: { 2: [0] },
    preferredDistricts: ["Kozhikode", "Kannur"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Kozhikode",
    bio: "Looking for someone with good values.",
    photoUrl: "https://picsum.photos/seed/amina/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Jinto_99821",
    phone: "9000000005",
    firstName: "Jinto",
    lastName: "Joseph",
    nickname: "Jinto",
    password: "Password@123",
    gender: Gender.MALE,
    age: 35,
    height: 178,
    religionId: 3,
    casteId: 2,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.SECOND,
    educationLevel: "Diploma",
    occupation: "Gulf Job (Technical)",
    fatherName: "Joseph",
    fatherOccupation: "Retired",
    motherName: "Leelamma",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Average",
    preferredHeightMin: 155,
    preferredHeightMax: 170,
    preferredReligions: [3],
    preferredCastes: { 3: [0] },
    preferredDistricts: ["Idukki", "Ernakulam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India", "UAE"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "UAE",
    state: "Others",
    district: "Idukki",
    bio: "Divorced, looking for a second chance at life.",
    photoUrl: "https://picsum.photos/seed/jinto/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Rose_11204",
    phone: "9000000006",
    firstName: "Rose",
    lastName: "Mary",
    nickname: "Rose",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 29,
    height: 164,
    religionId: 3,
    casteId: 5,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "B.Sc",
    occupation: "Staff Nurse",
    fatherName: "Abraham",
    fatherOccupation: "Farmer",
    motherName: "Molly",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Average",
    preferredHeightMin: 172,
    preferredHeightMax: 185,
    preferredReligions: [3],
    preferredCastes: { 3: [5] },
    preferredDistricts: ["Ernakulam", "Kottayam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Ernakulam",
    bio: "God-fearing and family-oriented.",
    photoUrl: "https://picsum.photos/seed/rose/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Arjun_44321",
    phone: "9000000007",
    firstName: "Arjun",
    lastName: "Das",
    nickname: "Arjun",
    password: "Password@123",
    gender: Gender.MALE,
    age: 31,
    height: 170,
    religionId: 4,
    casteId: 3,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "B.Com",
    occupation: "Banking Professional",
    fatherName: "Damodaran",
    fatherOccupation: "Retired",
    motherName: "Lalitha",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Physically Fit",
    preferredHeightMin: 155,
    preferredHeightMax: 165,
    preferredReligions: [4],
    preferredCastes: { 4: [0] },
    preferredDistricts: ["Kottayam", "Pathanamthitta"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Kottayam",
    bio: "Independent and looking for a compatible partner.",
    photoUrl: "https://picsum.photos/seed/arjun/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Suma_88432",
    phone: "9000000008",
    firstName: "Suma",
    lastName: "Pulaya",
    nickname: "Suma",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 32,
    height: 158,
    religionId: 4,
    casteId: 1,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.SECOND,
    educationLevel: "Diploma",
    occupation: "Government Employee (State)",
    fatherName: "Kuttan",
    fatherOccupation: "Deceased",
    motherName: "Sarasu",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Average",
    preferredHeightMin: 165,
    preferredHeightMax: 180,
    preferredReligions: [4],
    preferredCastes: { 4: [1] },
    preferredDistricts: ["Palakkad", "Thrissur"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Palakkad",
    bio: "Seeking a sincere and understanding partner.",
    photoUrl: "https://picsum.photos/seed/suma/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Vishnu_22109",
    phone: "9000000009",
    firstName: "Vishnu",
    lastName: "Prasad",
    nickname: "Vishnu",
    password: "Password@123",
    gender: Gender.MALE,
    age: 29,
    height: 180,
    religionId: 1,
    casteId: 3,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "M.Tech",
    occupation: "Data Scientist",
    fatherName: "Parameswaran",
    fatherOccupation: "Retired Principal",
    motherName: "Girija",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Athletic",
    preferredHeightMin: 160,
    preferredHeightMax: 175,
    preferredReligions: [1],
    preferredCastes: { 1: [3] },
    preferredDistricts: ["Kannur", "Kasaragod"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Kannur",
    bio: "Academic-oriented and looking for a professional partner.",
    photoUrl: "https://picsum.photos/seed/vishnu/400/600",
    isVerified: true,
    isDisabled: false
  },
  {
    id: "Kavya_66543",
    phone: "9000000010",
    firstName: "Kavya",
    lastName: "Menon",
    nickname: "Kavya",
    password: "Password@123",
    gender: Gender.FEMALE,
    age: 26,
    height: 163,
    religionId: 1,
    casteId: 1,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: "MBA",
    occupation: "Digital Marketer",
    fatherName: "Prabhakaran",
    fatherOccupation: "Business",
    motherName: "Sreelatha",
    motherOccupation: "Home Maker",
    siblings: [],
    bodyType: "Slim",
    preferredHeightMin: 175,
    preferredHeightMax: 188,
    preferredReligions: [1],
    preferredCastes: { 1: [1] },
    preferredDistricts: ["Thrissur", "Ernakulam"],
    preferredStates: ["Kerala"],
    preferredCountries: ["India"],
    preferredOccupations: [],
    preferredPentecostal: false,
    preferredBrethren: false,
    country: "India",
    state: "Kerala",
    district: "Thrissur",
    bio: "Looking for a creative and fun-loving partner.",
    photoUrl: "https://picsum.photos/seed/kavya/400/600",
    isVerified: true,
    isDisabled: false
  }
];

const App: React.FC = () => {
  const [state, setState] = useState<UserState>(() => {
    const saved = localStorage.getItem('soul_links_state_v6');
    if (saved) return JSON.parse(saved);
    return {
      currentUser: null,
      currentStaff: null,
      isSuperAdmin: false,
      profiles: INITIAL_PROFILES,
      staff: [],
      logs: [],
      messages: [],
      security: {
        adminUsername: DEFAULT_ADMIN_USERNAME,
        adminPasswordHash: DEFAULT_ADMIN_PASSWORD,
        adminPin: "1234",
        isFirstLogin: true,
        allowedStaffIPs: [],
        blockedUserIPs: []
      }
    };
  });

  const [otpTarget, setOtpTarget] = useState<{ role: 'user' | 'staff' | 'admin', payload: any, type: 'register' | 'login' | 'reset' } | null>(null);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  useEffect(() => {
    localStorage.setItem('soul_links_state_v6', JSON.stringify(state));
  }, [state]);

  const handleLoginAttempt = (phone: string, password?: string) => {
    const userIP = getClientIP();
    const user = state.profiles.find(p => p.phone === phone);
    if (user && !user.isDisabled && user.password === password) {
      setState(prev => ({ ...prev, currentUser: { ...user, lastLoginIP: userIP }, isSuperAdmin: false, currentStaff: null }));
    } else if (user?.isDisabled) {
      alert("Account Restricted: Contact support.");
    } else {
      alert("Invalid phone number or password.");
    }
  };

  const handleStaffLoginAttempt = (phone: string, password?: string) => {
    if (!isMobileDevice()) {
      alert("Staff portal restricted to mobile devices only.");
      return;
    }
    const staffMember = state.staff.find(s => s.phone === phone && s.isActive);
    if (!staffMember || staffMember.password !== password) {
      alert("Invalid staff credentials.");
      return;
    }
    const currentIP = getClientIP();
    if (state.security.allowedStaffIPs.length > 0 && !state.security.allowedStaffIPs.includes(currentIP)) {
      alert("Access Denied: IP not authorized.");
      return;
    }
    setState(prev => ({ ...prev, currentStaff: staffMember, isSuperAdmin: false, currentUser: null, logs: [createLog(staffMember.id, "Staff Login"), ...prev.logs] }));
  };

  const handleAdminLoginAttempt = (username: string, pass: string, pin?: string) => {
    if (
      username === state.security.adminUsername && 
      pass === state.security.adminPasswordHash &&
      (!state.security.adminPin || pin === state.security.adminPin)
    ) {
      setState(prev => ({ ...prev, isSuperAdmin: true, currentUser: null, currentStaff: null }));
    } else {
      alert("Invalid Admin Credentials (Check Username, Password & Secret PIN)");
    }
  };

  const logout = () => {
    setState(prev => ({ ...prev, currentUser: null, currentStaff: null, isSuperAdmin: false }));
  };

  const deleteProfile = (id: string) => {
    setState(prev => {
      const isCurrent = prev.currentUser?.id === id;
      return {
        ...prev,
        profiles: prev.profiles.filter(p => p.id !== id),
        currentUser: isCurrent ? null : prev.currentUser,
        messages: prev.messages.filter(m => m.senderId !== id && m.receiverId !== id),
        logs: [createLog(prev.isSuperAdmin ? 'admin' : (prev.currentStaff?.id || 'system'), `Deleted Profile: ${id}`), ...prev.logs]
      };
    });
  };

  const sendMessage = (senderId: string, receiverId: string, text: string) => {
    const newMessage: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      senderId,
      receiverId,
      text,
      timestamp: new Date().toISOString()
    };
    setState(prev => ({ ...prev, messages: [...prev.messages, newMessage] }));
  };

  const setupAdmin = (u: string, p: string, pin: string) => {
    setState(prev => ({
      ...prev,
      security: {
        ...prev.security,
        adminUsername: u,
        adminPasswordHash: p,
        adminPin: pin,
        isFirstLogin: false
      }
    }));
  };

  const handleResetPassword = (phone: string, newPassword: string) => {
    setState(prev => ({
      ...prev,
      profiles: prev.profiles.map(p => p.phone === phone ? { ...p, password: newPassword } : p),
      staff: prev.staff.map(s => s.phone === phone ? { ...s, password: newPassword } : s)
    }));
  };

  return (
    <Router>
      <Layout 
        currentUser={state.currentUser} 
        currentStaff={state.currentStaff} 
        isSuperAdmin={state.isSuperAdmin} 
        messages={state.messages}
        onSendMessage={sendMessage}
        onLogout={logout}
      >
        <Routes>
          <Route path="/" element={<Home 
            currentUser={state.currentUser} 
            currentStaff={state.currentStaff}
            isSuperAdmin={state.isSuperAdmin}
            profiles={state.profiles} 
          />} />
          <Route path="/login" element={<Login 
            onLoginAttempt={handleLoginAttempt} 
            onStaffLoginAttempt={handleStaffLoginAttempt}
            onAdminLoginAttempt={handleAdminLoginAttempt}
            onForgotPassword={() => setShowForgotPassword(true)}
          />} />
          <Route path="/register" element={<Register onRegister={(p) => setOtpTarget({role:'user', payload:p, type:'register'})} profiles={state.profiles} />} />
          <Route path="/admin-setup" element={<AdminRegister onSetup={setupAdmin} isFirstLogin={state.security.isFirstLogin} />} />
          <Route path="/matches" element={state.currentUser || state.currentStaff || state.isSuperAdmin ? <Matches currentUser={state.currentUser} profiles={state.profiles} staffView={!!state.currentStaff || state.isSuperAdmin} onAction={(a) => setState(prev => ({...prev, logs: [createLog(state.currentStaff?.id || 'admin', a), ...prev.logs]}))} /> : <Navigate to="/login" />} />
          <Route path="/profile" element={state.currentUser ? <ProfilePage user={state.currentUser} onUpdate={(u) => setState(prev => ({ ...prev, profiles: prev.profiles.map(p => p.phone === u.phone ? u : p), currentUser: u }))} onDelete={deleteProfile} /> : <Navigate to="/login" />} />
          <Route path="/admin" element={state.isSuperAdmin ? <AdminDashboard state={state} setState={setState} onDeleteProfile={deleteProfile} onSendMessage={sendMessage} /> : <Navigate to="/login" />} />
          <Route path="/staff" element={state.currentStaff ? <StaffDashboard staff={state.currentStaff} profiles={state.profiles} onAction={(a) => setState(prev => ({...prev, logs: [createLog(state.currentStaff!.id, a), ...prev.logs]}))} /> : <Navigate to="/login" />} />
        </Routes>
      </Layout>

      {otpTarget && (
        <OTPModal 
          onVerify={() => {
            const profile = otpTarget.payload as Profile;
            setState(prev => ({ ...prev, profiles: [...prev.profiles, profile], currentUser: profile }));
            setOtpTarget(null);
          }} 
          onCancel={() => setOtpTarget(null)} 
          target={otpTarget.payload.phone || 'Account'} 
        />
      )}
      {showForgotPassword && <ForgotPasswordModal 
        onClose={() => setShowForgotPassword(false)} 
        onReset={handleResetPassword} 
        profiles={state.profiles}
        staff={state.staff}
      />}
    </Router>
  );
};

export default App;
