
import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Shield, X, MessageCircle } from 'lucide-react';
import { ChatMessage, Profile } from '../types';

interface ChatWindowProps {
  messages: ChatMessage[];
  currentUserId: string; // 'admin' or profile.id
  targetUserId: string; // 'admin' or profile.id
  targetName: string;
  onSendMessage: (senderId: string, receiverId: string, text: string) => void;
  onClose?: () => void;
  isFloating?: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ 
  messages, 
  currentUserId, 
  targetUserId, 
  targetName, 
  onSendMessage, 
  onClose,
  isFloating = false
}) => {
  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const conversation = messages.filter(m => 
    (m.senderId === currentUserId && m.receiverId === targetUserId) ||
    (m.senderId === targetUserId && m.receiverId === currentUserId)
  ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(currentUserId, targetUserId, inputText.trim());
    setInputText('');
  };

  return (
    <div className={`flex flex-col bg-white border border-gray-100 overflow-hidden ${isFloating ? 'fixed bottom-4 right-4 w-80 h-[450px] shadow-2xl rounded-[2rem] z-[100]' : 'h-full rounded-3xl shadow-lg'}`}>
      {/* Header */}
      <div className={`p-4 flex items-center justify-between ${currentUserId === 'admin' ? 'bg-gray-900 text-white' : 'bg-rose-600 text-white'}`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            {targetUserId === 'admin' ? <Shield className="w-4 h-4" /> : <User className="w-4 h-4" />}
          </div>
          <div>
            <div className="text-xs font-black uppercase tracking-widest">{targetName}</div>
            <div className="text-[10px] opacity-60 font-bold">{targetUserId === 'admin' ? 'Support Helpdesk' : 'Member Profile'}</div>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-grow p-4 overflow-y-auto bg-gray-50 space-y-4 scroll-smooth">
        {conversation.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2 opacity-30">
            <MessageCircle className="w-12 h-12" />
            <p className="text-xs font-black uppercase tracking-tighter">No messages yet. Start the conversation!</p>
          </div>
        ) : (
          conversation.map((msg) => (
            <div key={msg.id} className={`flex ${msg.senderId === currentUserId ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-3 rounded-2xl text-sm font-medium shadow-sm ${msg.senderId === currentUserId 
                ? (currentUserId === 'admin' ? 'bg-gray-900 text-white rounded-br-none' : 'bg-rose-600 text-white rounded-br-none') 
                : 'bg-white text-gray-800 border border-gray-100 rounded-bl-none'}`}>
                {msg.text}
                <div className={`text-[8px] mt-1 opacity-60 text-right ${msg.senderId === currentUserId ? 'text-white' : 'text-gray-400'}`}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-4 bg-white border-t border-gray-50 flex gap-2">
        <input 
          type="text" 
          placeholder="Type message..." 
          className="flex-1 bg-gray-50 p-3 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-rose-500 transition-all"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />
        <button type="submit" className={`p-3 rounded-xl transition-all active:scale-95 shadow-lg ${currentUserId === 'admin' ? 'bg-gray-900 text-white shadow-gray-500/20' : 'bg-rose-600 text-white shadow-rose-500/20'}`}>
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};

export default ChatWindow;
