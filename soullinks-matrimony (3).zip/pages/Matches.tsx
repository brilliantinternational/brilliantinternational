
import React, { useState, useMemo } from 'react';
import { Profile, Gender } from '../types';
import { RELIGIONS, CASTES, DISTRICTS } from '../constants';
import ProfileCard from '../components/ProfileCard';
import { SlidersHorizontal, Search, X, Check, ShieldCheck, Heart } from 'lucide-react';

interface MatchesProps {
  currentUser: Profile | null;
  profiles: Profile[];
  staffView?: boolean;
  onAction?: (action: string) => void;
}

const Matches: React.FC<MatchesProps> = ({ currentUser, profiles, staffView, onAction }) => {
  const [filters, setFilters] = useState({
    ageMin: 18,
    ageMax: 60,
    religionId: 0,
    casteId: 0,
    district: '',
    searchQuery: '',
    strictPrefs: !!currentUser && !staffView // Suggestions logic only for users
  });

  const [showFilters, setShowFilters] = useState(false);

  const filteredProfiles = useMemo(() => {
    return profiles.filter(p => {
      // 1. SUGGESTION / PREFERENCE LOGIC (ONLY FOR USERS)
      if (currentUser && !staffView) {
         if (p.phone === currentUser.phone) return false;
         const targetGender = currentUser.gender === Gender.MALE ? Gender.FEMALE : Gender.MALE;
         if (p.gender !== targetGender) return false;
         
         // INTERNAL PREFERENCE ENFORCEMENT
         if (filters.strictPrefs) {
           // Height
           if (p.height < currentUser.preferredHeightMin || p.height > currentUser.preferredHeightMax) return false;
           
           // Religions
           if (currentUser.preferredReligions.length > 0 && !currentUser.preferredReligions.includes(p.religionId)) return false;
           
           // Castes (including ALL logic)
           const religionCastePrefs = currentUser.preferredCastes[p.religionId];
           if (religionCastePrefs && religionCastePrefs.length > 0) {
              const isAll = religionCastePrefs.includes(0);
              if (!isAll && !religionCastePrefs.includes(p.casteId)) return false;
           }

           // Pentecostal / Brethren Logic
           if (currentUser.preferredPentecostal && !p.isPentecostal) return false;
           if (currentUser.preferredBrethren && !p.isBrethren) return false;

           // Job Preference Logic
           if (currentUser.preferredOccupations.length > 0) {
             const jobMatches = currentUser.preferredOccupations.includes(p.occupation) || 
                               (p.occupation === 'Others' && currentUser.preferredOccupationOthers && p.occupationOthers?.toLowerCase().includes(currentUser.preferredOccupationOthers.toLowerCase()));
             if (!jobMatches) return false;
           }
           
           // Location Logic (Country)
           if (currentUser.preferredCountries.length > 0) {
             const countryMatches = currentUser.preferredCountries.includes(p.country) || 
                                   (p.country === 'Others' && currentUser.preferredCountryOthers && p.countryOthers?.toLowerCase().includes(currentUser.preferredCountryOthers.toLowerCase()));
             if (!countryMatches) return false;
           }

           // Location Logic (State)
           if (currentUser.preferredStates.length > 0) {
             const stateMatches = currentUser.preferredStates.includes(p.state) || 
                                 (p.state === 'Others' && currentUser.preferredStateOthers && p.stateOthers?.toLowerCase().includes(currentUser.preferredStateOthers.toLowerCase()));
             if (!stateMatches) return false;
           }

           // Districts (Only if state is Kerala)
           if (p.state === 'Kerala' && currentUser.preferredDistricts.length > 0 && !currentUser.preferredDistricts.includes(p.district)) return false;
         }
      }

      // 2. MANUAL DIRECTORY FILTERS (STAFF/ADMIN VIEW)
      if (p.age < filters.ageMin || p.age > filters.ageMax) return false;
      if (filters.religionId && p.religionId !== filters.religionId) return false;
      if (filters.casteId && p.casteId !== filters.casteId) return false;
      if (filters.district && p.district !== filters.district) return false;
      
      const search = filters.searchQuery.toLowerCase();
      if (search && !p.nickname.toLowerCase().includes(search) && !p.id.toLowerCase().includes(search)) return false;

      return true;
    });
  }, [profiles, currentUser, filters, staffView]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h1 className="text-3xl font-black text-gray-900">{staffView ? 'Directory Browser' : 'Soul Matches'}</h1>
          <p className="text-gray-500 text-sm font-bold">{filteredProfiles.length} profiles available.</p>
        </div>
        <div className="flex w-full md:w-auto gap-2">
          {currentUser && !staffView && (
            <button 
              onClick={() => setFilters(p => ({ ...p, strictPrefs: !p.strictPrefs }))}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border flex items-center gap-2 ${filters.strictPrefs ? 'bg-blue-50 border-blue-200 text-blue-600' : 'bg-white border-gray-100 text-gray-400'}`}
            >
              <ShieldCheck className="w-3 h-3" /> Personal Suggestions
            </button>
          )}
          <div className="relative flex-grow md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              type="text" placeholder="Search Profile ID..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-xl outline-none font-bold"
              value={filters.searchQuery}
              onChange={e => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
            />
          </div>
          <button onClick={() => setShowFilters(!showFilters)} className="px-4 py-2 flex items-center gap-2 font-black text-xs uppercase tracking-widest rounded-xl transition-colors bg-white text-gray-700 border border-gray-200">
            <SlidersHorizontal className="w-4 h-4" /> Filters
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="bg-white p-8 rounded-[2rem] border border-rose-100 shadow-lg animate-in slide-in-from-top duration-300">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Age Range</label>
              <div className="flex items-center gap-2">
                <input type="number" value={filters.ageMin} onChange={e => setFilters(prev => ({ ...prev, ageMin: Number(e.target.value) }))} className="w-full p-3 bg-gray-50 rounded-xl text-sm font-bold" />
                <span className="text-gray-300">-</span>
                <input type="number" value={filters.ageMax} onChange={e => setFilters(prev => ({ ...prev, ageMax: Number(e.target.value) }))} className="w-full p-3 bg-gray-50 rounded-xl text-sm font-bold" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Religion</label>
              <select value={filters.religionId} onChange={e => setFilters(prev => ({ ...prev, religionId: Number(e.target.value), casteId: 0 }))} className="w-full p-3 bg-gray-50 rounded-xl text-sm font-bold">
                <option value={0}>All Religions</option>
                {RELIGIONS.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Caste</label>
              <select value={filters.casteId} onChange={e => setFilters(prev => ({ ...prev, casteId: Number(e.target.value) }))} disabled={!filters.religionId} className="w-full p-3 bg-gray-50 rounded-xl text-sm font-bold">
                <option value={0}>All Castes</option>
                {filters.religionId > 0 && CASTES[filters.religionId]?.map((c, i) => <option key={i} value={i+1}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">District</label>
              <select value={filters.district} onChange={e => setFilters(prev => ({ ...prev, district: e.target.value }))} className="w-full p-3 bg-gray-50 rounded-xl text-sm font-bold">
                <option value="">All Kerala</option>
                {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
          </div>
        </div>
      )}

      {filteredProfiles.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProfiles.map(p => (
            <ProfileCard 
              key={p.id} 
              profile={p} 
              showPhone={staffView} 
              isUser={!!currentUser && !staffView}
              onPhoneClick={() => staffView && onAction && onAction(`Accessed Phone: ${p.id}`)} 
            />
          ))}
        </div>
      ) : (
        <div className="py-32 text-center space-y-4">
          <Heart className="w-12 h-12 text-rose-200 mx-auto" />
          <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight">No Profiles Match Filters</h3>
        </div>
      )}
    </div>
  );
};

export default Matches;
