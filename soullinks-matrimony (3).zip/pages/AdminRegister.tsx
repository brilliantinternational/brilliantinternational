
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, ShieldCheck, Lock, User, Key, ArrowRight, Save, Shield, Eye, EyeOff, Info } from 'lucide-react';

interface AdminRegisterProps {
  onSetup: (username: string, pass: string, pin: string) => void;
  isFirstLogin: boolean;
}

const AdminRegister: React.FC<AdminRegisterProps> = ({ onSetup, isFirstLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [personalPin, setPersonalPin] = useState(''); // The PIN the user wants to use for login
  const [masterUnlockKey, setMasterUnlockKey] = useState(''); // The PIN '7777'
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFirstLogin) {
      alert("Admin credentials already exist. Use the login page.");
      return;
    }
    if (password !== confirmPassword) return alert("Passwords do not match!");
    if (password.length < 8) return alert("Security: Password must be 8+ characters.");
    if (personalPin.length !== 4) return alert("Your Secret PIN must be 4 digits.");
    if (masterUnlockKey !== '7777') return alert("Invalid Master Setup Key. Use 7777 to unlock this form.");

    onSetup(username, password, personalPin);
    alert("System Initialized! Use your new Username, Password, and PIN (" + personalPin + ") to login now.");
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <div className="bg-white rounded-[3.5rem] p-8 md:p-12 max-w-lg w-full shadow-2xl space-y-8 animate-in zoom-in duration-500 border-t-8 border-rose-600">
        
        <div className="bg-rose-50 border border-rose-100 p-6 rounded-3xl text-center space-y-2">
          <div className="flex items-center justify-center gap-2 text-rose-600 font-black text-xs uppercase tracking-widest">
            <ShieldCheck className="w-4 h-4" /> Initial Website Setup
          </div>
          <p className="text-xs text-rose-800 font-bold leading-relaxed">
            Welcome Owner. To unlock this form, use Master Key: <span className="text-lg font-black text-rose-600">7777</span>
          </p>
        </div>

        <div className="text-center space-y-2">
          <div className="w-20 h-20 bg-gray-900 rounded-[2rem] flex items-center justify-center mx-auto shadow-xl rotate-3">
            <ShieldAlert className="w-10 h-10 text-rose-500" />
          </div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tighter uppercase">Root Admin Setup</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="p-6 bg-gray-100 rounded-3xl border-2 border-dashed border-gray-200 space-y-3">
               <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block text-center">Step 1: Unlock Form (Master Key)</label>
               <input
                type="text"
                maxLength={4}
                placeholder="7777"
                required
                className="w-full p-4 bg-white border border-gray-200 rounded-2xl text-center text-3xl font-black tracking-[1em] focus:ring-2 focus:ring-rose-500 outline-none"
                value={masterUnlockKey}
                onChange={(e) => setMasterUnlockKey(e.target.value)}
              />
            </div>

            <div className="space-y-4 pt-4 border-t border-gray-100">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">Step 2: Create Your Credentials</label>
              
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Set Admin Username"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none font-bold"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Set Admin Password"
                  required
                  className="w-full pl-12 pr-12 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none font-bold"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-rose-600">
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <input
                type={showPassword ? "text" : "password"}
                placeholder="Confirm Admin Password"
                required
                className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none font-bold"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />

              <div className="relative group">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  maxLength={4}
                  placeholder="Set Your Secret Login PIN"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-rose-50 border border-rose-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none font-black text-center tracking-[1em]"
                  value={personalPin}
                  onChange={(e) => setPersonalPin(e.target.value)}
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-rose-600 text-white py-5 rounded-2xl font-black text-lg transition shadow-xl flex items-center justify-center gap-2 hover:bg-rose-700 active:scale-95"
          >
            Create Admin Account <Save className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminRegister;
