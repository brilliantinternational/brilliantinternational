
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Profile, Staff, Gender } from '../types';
import { Shield, Heart, Phone, Users, CheckCircle } from 'lucide-react';
import ProfileCard from '../components/ProfileCard';

interface HomeProps {
  currentUser: Profile | null;
  currentStaff: Staff | null;
  isSuperAdmin: boolean;
  profiles: Profile[];
}

const Home: React.FC<HomeProps> = ({ currentUser, currentStaff, isSuperAdmin, profiles }) => {
  const isInternal = isSuperAdmin || currentStaff;
  
  const featuredProfiles = useMemo(() => {
    let list = profiles;
    if (currentUser && !isInternal) {
      const targetGender = currentUser.gender === Gender.MALE ? Gender.FEMALE : Gender.MALE;
      list = list.filter(p => p.gender === targetGender && p.id !== currentUser.id);
    }
    return list.slice(0, 4);
  }, [profiles, currentUser, isInternal]);

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&q=80&w=2000" 
            alt="Kerala Wedding" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-rose-900/90 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-2xl space-y-6">
            <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-300 text-sm font-semibold backdrop-blur-md">
              <CheckCircle className="w-4 h-4 mr-2" />
              100% Free & Secure
            </div>
            <h1 className="text-5xl md:text-7xl font-black leading-tight">
              {isSuperAdmin ? 'Master Dashboard' : 'Find Your Eternal Soulmate Today'}
            </h1>
            <p className="text-xl text-rose-50 opacity-90 leading-relaxed">
              {isSuperAdmin 
                ? 'Welcome back, Owner. Monitor registrations and manage platform security from the Root Console.' 
                : "Kerala's most trusted FREE platform for first and second marriages. Connecting hearts through tradition, trust, and transparency."}
            </p>
            {!currentUser && !isInternal && (
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link to="/register" className="px-8 py-4 bg-rose-600 text-white text-lg font-bold rounded-xl hover:bg-rose-700 transition-all shadow-xl hover:shadow-rose-500/20 text-center">
                  Create Free Profile
                </Link>
                <Link to="/login" className="px-8 py-4 bg-white/10 backdrop-blur-md text-white text-lg font-bold rounded-xl border border-white/20 hover:bg-white/20 transition-all text-center">
                  Member Login
                </Link>
              </div>
            )}
            {isSuperAdmin && (
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link to="/admin" className="px-8 py-4 bg-white text-gray-900 text-lg font-black rounded-xl hover:bg-gray-100 transition-all shadow-xl text-center uppercase tracking-widest">
                  Open Root Console
                </Link>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Trust Stats */}
      <section className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
        {[
          { icon: Users, label: 'Verified Profiles', value: '10,000+' },
          { icon: Heart, label: 'Happy Unions', value: '2,500+' },
          { icon: Shield, label: 'Privacy Control', value: '100%' },
          { icon: Phone, label: 'Human Support', value: '24/7' },
        ].map((stat, i) => (
          <div key={i} className="text-center p-6 bg-white rounded-3xl shadow-sm border border-gray-100">
            <stat.icon className="w-8 h-8 text-rose-600 mx-auto mb-3" />
            <h4 className="text-2xl font-black text-gray-900">{stat.value}</h4>
            <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
          </div>
        ))}
      </section>

      {/* Featured Profiles (Suggestions) - ONLY SHOW FOR USERS, NOT ADMIN/STAFF */}
      {!isInternal && (
        <section className="max-w-7xl mx-auto px-4 space-y-8 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-between items-end">
            <div>
              <h2 className="text-3xl font-black text-gray-900">Featured Profiles</h2>
              <p className="text-gray-500">People matching your cultural roots</p>
            </div>
            <Link to="/matches" className="text-rose-600 font-bold hover:underline">View All Matches →</Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProfiles.map(profile => (
              <ProfileCard 
                key={profile.id} 
                profile={profile} 
                isUser={!!currentUser} 
              />
            ))}
          </div>
        </section>
      )}

      {/* Legal & Restrictions Warning */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="bg-rose-50 border-2 border-rose-100 rounded-3xl p-8 text-center space-y-4">
          <div className="w-12 h-12 bg-rose-600 rounded-full flex items-center justify-center mx-auto shadow-lg">
            <Shield className="text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">Strict Matrimony Only</h3>
          <p className="text-gray-600 leading-relaxed">
            SoulLinks Matrimony is a sacred platform designed for those seeking lifelong companionship through marriage. 
            <span className="block font-bold text-rose-700 mt-2">Dating is strictly prohibited. Any misuse of this platform will lead to permanent ban.</span>
          </p>
          <div className="text-sm text-gray-400 font-medium">
            Authorized by Brilliant International
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
