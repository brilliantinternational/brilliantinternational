
import React, { useState, useMemo } from 'react';
import { UserState, Profile, Staff, Gender, MaritalStatus } from '../types';
import { RELIGIONS, CASTES, DISTRICTS } from '../constants';
import { exportToExcel, createLog } from '../utils';
import ChatWindow from '../components/ChatWindow';
import { 
  ShieldCheck, Download, Users, UserPlus, ListTodo, Globe, Trash2, 
  ShieldAlert, Search, Filter, CheckCircle, XCircle, UserMinus, UserCheck, 
  PhoneCall, FileSpreadsheet, Lock, Key, Save, User, Eye, EyeOff, MessageCircle
} from 'lucide-react';

interface AdminDashboardProps {
  state: UserState;
  setState: React.Dispatch<React.SetStateAction<UserState>>;
  onDeleteProfile: (id: string) => void;
  onSendMessage: (senderId: string, receiverId: string, text: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ state, setState, onDeleteProfile, onSendMessage }) => {
  const [tab, setTab] = useState<'profiles' | 'staff' | 'logs' | 'chats' | 'security'>('profiles');
  const [activeChatUserId, setActiveChatUserId] = useState<string | null>(null);
  const [newStaffPhone, setNewStaffPhone] = useState('');
  const [newStaffName, setNewStaffName] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Admin Credential Editing
  const [editAdmin, setEditAdmin] = useState({
    username: state.security.adminUsername,
    password: '', // Leave blank to not change
    pin: state.security.adminPin
  });

  const [filters, setFilters] = useState({
    gender: 0,
    ageExact: '',
    ageMin: '',
    ageMax: '',
    religionId: 0,
    casteId: 0,
    district: '',
    maritalStatus: 0,
    searchId: '',
    isVerified: 'all' 
  });

  const filteredProfiles = useMemo(() => {
    return state.profiles.filter(p => {
      if (filters.gender && p.gender !== filters.gender) return false;
      if (filters.ageExact && p.age !== parseInt(filters.ageExact)) return false;
      if (filters.ageMin && p.age < parseInt(filters.ageMin)) return false;
      if (filters.ageMax && p.age > parseInt(filters.ageMax)) return false;
      if (filters.religionId && p.religionId !== filters.religionId) return false;
      if (filters.casteId && p.casteId !== filters.casteId) return false;
      if (filters.district && p.district !== filters.district) return false;
      if (filters.maritalStatus && p.maritalStatus !== filters.maritalStatus) return false;
      if (filters.searchId && !p.id.toLowerCase().includes(filters.searchId.toLowerCase())) return false;
      if (filters.isVerified === 'verified' && !p.isVerified) return false;
      if (filters.isVerified === 'unverified' && p.isVerified) return false;
      return true;
    });
  }, [state.profiles, filters]);

  // List of unique user IDs who have chatted with admin
  const activeChats = useMemo(() => {
    const userIds = new Set<string>();
    state.messages.forEach(m => {
      if (m.senderId !== 'admin') userIds.add(m.senderId);
      if (m.receiverId !== 'admin') userIds.add(m.receiverId);
    });
    return state.profiles.filter(p => userIds.has(p.id));
  }, [state.messages, state.profiles]);

  const toggleVerify = (profileId: string) => {
    setState(prev => {
      const profile = prev.profiles.find(p => p.id === profileId);
      const newStatus = !profile?.isVerified;
      return {
        ...prev,
        profiles: prev.profiles.map(p => p.id === profileId ? { ...p, isVerified: newStatus } : p),
        logs: [createLog('admin', `[Verification] Set ${profileId} to ${newStatus ? 'Verified' : 'Unverified'}`), ...prev.logs]
      };
    });
  };

  const toggleStatus = (profileId: string) => {
    setState(prev => {
      const profile = prev.profiles.find(p => p.id === profileId);
      const newStatus = !profile?.isDisabled;
      return {
        ...prev,
        profiles: prev.profiles.map(p => p.id === profileId ? { ...p, isDisabled: newStatus } : p),
        logs: [createLog('admin', `[Status] Set ${profileId} to ${newStatus ? 'Disabled' : 'Enabled'}`), ...prev.logs]
      };
    });
  };

  const handleDeleteProfile = (profileId: string) => {
    // Log the attempt
    setState(prev => ({
      ...prev,
      logs: [createLog('admin', `[Delete Attempt] Initiated for ${profileId}`), ...prev.logs]
    }));

    const confirmed = window.confirm(`ROOT ACTION: Delete profile ${profileId} permanently? This cannot be undone.`);
    if (confirmed) {
      onDeleteProfile(profileId);
    } else {
      setState(prev => ({
        ...prev,
        logs: [createLog('admin', `[Delete Attempt] Cancelled by user for ${profileId}`), ...prev.logs]
      }));
    }
  };

  const handleExportFiltered = () => {
    exportToExcel(filteredProfiles, `Admin_Export_${new Date().toISOString().split('T')[0]}`);
    setState(prev => ({
      ...prev,
      logs: [createLog('admin', `[Export] Performed Excel export for ${filteredProfiles.length} profiles`), ...prev.logs]
    }));
  };

  const handleAddStaff = (e: React.FormEvent) => {
    e.preventDefault();
    const newS: Staff = {
      id: `staff_${Date.now()}`,
      phone: newStaffPhone,
      name: newStaffName,
      password: 'staff123',
      isActive: true
    };
    setState(prev => ({ 
      ...prev, 
      staff: [...prev.staff, newS],
      logs: [createLog('admin', `[Staff] Created new staff account: ${newStaffName} (${newStaffPhone})`), ...prev.logs]
    }));
    setNewStaffPhone('');
    setNewStaffName('');
  };

  const handleSaveAdminCreds = () => {
    if (!editAdmin.username || editAdmin.username.length < 3) return alert("Username too short (min 3 chars)");
    if (editAdmin.password && editAdmin.password.length < 8) return alert("New password must be 8+ chars");
    if (editAdmin.pin.length !== 4) return alert("Secret Login PIN must be exactly 4 digits");

    setState(prev => ({
      ...prev,
      security: {
        ...prev.security,
        adminUsername: editAdmin.username,
        adminPasswordHash: editAdmin.password || prev.security.adminPasswordHash, // Keep old if blank
        adminPin: editAdmin.pin
      },
      logs: [createLog('admin', `[Security] Root credentials updated (Username: ${editAdmin.username})`), ...prev.logs]
    }));
    alert("SYSTEM SECURED: Credentials Updated Successfully!\nNew PIN: " + editAdmin.pin + "\nUse these details for future logins.");
    setEditAdmin(prev => ({ ...prev, password: '' })); // Clear the password field after save
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-center bg-gray-900 p-8 rounded-[3.5rem] text-white shadow-2xl gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-rose-500 rounded-3xl flex items-center justify-center shadow-lg shadow-rose-500/20">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight">Master Console</h1>
            <p className="opacity-60 text-xs font-black uppercase tracking-widest">Root Admin Authorization</p>
          </div>
        </div>
        <div className="flex bg-white/5 p-1.5 rounded-2xl backdrop-blur-md overflow-x-auto">
          {['profiles', 'staff', 'chats', 'logs', 'security'].map((t) => (
            <button 
              key={t}
              onClick={() => setTab(t as any)}
              className={`px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${tab === t ? 'bg-white text-gray-900 shadow-xl' : 'text-white/40 hover:text-white hover:bg-white/10'}`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {tab === 'profiles' && (
        <div className="space-y-8 animate-in fade-in duration-500">
          <div className="bg-white p-8 rounded-[3rem] shadow-xl border border-gray-100">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Gender</label>
                <select value={filters.gender} onChange={e => setFilters({...filters, gender: Number(e.target.value)})} className="w-full p-4 bg-gray-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-rose-500">
                  <option value={0}>Any Gender</option>
                  <option value={Gender.MALE}>Male</option>
                  <option value={Gender.FEMALE}>Female</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Age Range</label>
                <div className="flex gap-2">
                   <input type="number" placeholder="Min" value={filters.ageMin} onChange={e => setFilters({...filters, ageMin: e.target.value})} className="w-full p-4 bg-gray-50 rounded-2xl font-bold border-none" />
                   <input type="number" placeholder="Max" value={filters.ageMax} onChange={e => setFilters({...filters, ageMax: e.target.value})} className="w-full p-4 bg-gray-50 rounded-2xl font-bold border-none" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Religion</label>
                <select value={filters.religionId} onChange={e => setFilters({...filters, religionId: Number(e.target.value)})} className="w-full p-4 bg-gray-50 rounded-2xl font-bold">
                  <option value={0}>Any Religion</option>
                  {RELIGIONS.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">District</label>
                <select value={filters.district} onChange={e => setFilters({...filters, district: e.target.value})} className="w-full p-4 bg-gray-50 rounded-2xl font-bold">
                  <option value="">Any District</option>
                  {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[3.5rem] shadow-xl border border-gray-100 overflow-hidden">
            <div className="p-10 border-b border-gray-50 flex justify-between items-center">
              <h3 className="text-2xl font-black text-gray-900">Directory ({filteredProfiles.length})</h3>
              <button onClick={handleExportFiltered} className="px-6 py-3 bg-emerald-600 text-white rounded-xl font-black text-xs flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4" /> Export (.xlsx)
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-8 py-6 text-xs font-black uppercase text-gray-400">Profile</th>
                    <th className="px-8 py-6 text-xs font-black uppercase text-gray-400">Identity</th>
                    <th className="px-8 py-6 text-xs font-black uppercase text-gray-400">Status</th>
                    <th className="px-8 py-6 text-xs font-black uppercase text-gray-400">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {filteredProfiles.map(p => (
                    <tr key={p.id}>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <img src={p.photoUrl} className="w-12 h-12 rounded-xl object-cover" />
                          <div>
                            <div className="font-black">{p.nickname}</div>
                            <div className="text-[10px] text-rose-500 uppercase tracking-widest">{p.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <a href={`tel:${p.phone}`} className="text-indigo-600 font-mono font-black">{p.phone}</a>
                        <div className="text-[10px] text-gray-400 font-bold">{p.district}</div>
                      </td>
                      <td className="px-8 py-6">
                         <div className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest text-center ${p.isVerified ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-400'}`}>
                           {p.isVerified ? 'Verified' : 'Unverified'}
                         </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex gap-2">
                           <button onClick={() => toggleVerify(p.id)} title="Verify Toggle" className="p-2 bg-gray-100 rounded-lg hover:bg-emerald-100 text-gray-400 hover:text-emerald-600 transition-all"><CheckCircle className="w-4 h-4" /></button>
                           <button onClick={() => toggleStatus(p.id)} title="Disable Toggle" className={`p-2 rounded-lg transition-all ${p.isDisabled ? 'bg-amber-600 text-white' : 'bg-gray-100 text-gray-400 hover:bg-amber-100 hover:text-amber-600'}`}><UserMinus className="w-4 h-4" /></button>
                           <button onClick={() => {
                             setActiveChatUserId(p.id);
                             setTab('chats');
                           }} title="Chat with User" className="p-2 bg-gray-100 rounded-lg hover:bg-blue-100 text-gray-400 hover:text-blue-600 transition-all"><MessageCircle className="w-4 h-4" /></button>
                           <button onClick={() => handleDeleteProfile(p.id)} title="Delete Profile" className="p-2 bg-gray-100 rounded-lg hover:bg-rose-100 text-gray-400 hover:text-rose-600 transition-all"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'chats' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 h-[600px] animate-in fade-in duration-500">
          <div className="lg:col-span-1 bg-white rounded-[3rem] shadow-xl border border-gray-100 flex flex-col">
            <div className="p-6 border-b border-gray-50">
              <h3 className="text-sm font-black uppercase tracking-widest text-gray-400">Active Conversations</h3>
            </div>
            <div className="flex-grow overflow-y-auto p-4 space-y-2">
              {activeChats.length === 0 ? (
                <div className="text-center p-8 space-y-2 opacity-20">
                  <MessageCircle className="w-10 h-10 mx-auto" />
                  <p className="text-[10px] font-black uppercase">No active chats</p>
                </div>
              ) : (
                activeChats.map(p => (
                  <button 
                    key={p.id} 
                    onClick={() => setActiveChatUserId(p.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-2xl transition-all ${activeChatUserId === p.id ? 'bg-rose-50 border border-rose-100' : 'hover:bg-gray-50 border border-transparent'}`}
                  >
                    <img src={p.photoUrl} className="w-10 h-10 rounded-xl object-cover" />
                    <div className="text-left">
                      <div className="text-xs font-black text-gray-900">{p.nickname}</div>
                      <div className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{p.id}</div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
          <div className="lg:col-span-3">
            {activeChatUserId ? (
              <ChatWindow 
                messages={state.messages} 
                currentUserId="admin" 
                targetUserId={activeChatUserId} 
                targetName={state.profiles.find(p => p.id === activeChatUserId)?.nickname || 'User'} 
                onSendMessage={onSendMessage}
              />
            ) : (
              <div className="h-full bg-white rounded-[3.5rem] shadow-xl border border-gray-100 flex flex-col items-center justify-center text-center p-12 space-y-4">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-10 h-10 text-gray-200" />
                </div>
                <div>
                  <h4 className="text-xl font-black text-gray-900">Communication Center</h4>
                  <p className="text-sm text-gray-400 font-bold max-w-xs mx-auto">Select a user from the directory or active chats list to start a support conversation.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'staff' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-500">
          <div className="lg:col-span-1 bg-white p-8 rounded-[3rem] border border-gray-100 shadow-xl">
            <h3 className="text-xl font-black mb-6">Create Staff</h3>
            <form onSubmit={handleAddStaff} className="space-y-4">
              <input type="text" placeholder="Name" required value={newStaffName} onChange={e => setNewStaffName(e.target.value)} className="w-full p-4 bg-gray-50 rounded-2xl border-none outline-none font-bold" />
              <input type="tel" placeholder="Phone" required value={newStaffPhone} onChange={e => setNewStaffPhone(e.target.value)} className="w-full p-4 bg-gray-50 rounded-2xl border-none outline-none font-bold" />
              <button type="submit" className="w-full py-4 bg-rose-600 text-white font-black rounded-2xl">Add Staff Member</button>
            </form>
          </div>
          <div className="lg:col-span-2 bg-white rounded-[3.5rem] border border-gray-100 shadow-xl overflow-hidden p-10">
             <h3 className="text-xl font-black mb-6">Staff Team</h3>
             <div className="space-y-4">
               {state.staff.map(s => (
                 <div key={s.id} className="flex justify-between items-center p-6 bg-gray-50 rounded-[2rem]">
                   <div className="font-black">{s.name} ({s.phone})</div>
                   <button onClick={() => {
                     setState(p => ({ 
                       ...p, 
                       staff: p.staff.filter(st => st.id !== s.id),
                       // Fixed: replaced 'prev' with 'p' in the functional update
                       logs: [createLog('admin', `[Staff] Removed staff member: ${s.name}`), ...p.logs]
                     }));
                   }} className="text-rose-500 hover:bg-rose-50 p-2 rounded-full transition-all"><Trash2 /></button>
                 </div>
               ))}
             </div>
          </div>
        </div>
      )}

      {tab === 'logs' && (
        <div className="bg-white rounded-[3.5rem] border border-gray-100 shadow-xl overflow-hidden animate-in fade-in duration-500">
           <table className="w-full text-left">
             <thead className="bg-gray-50">
               <tr>
                 <th className="px-10 py-6 text-xs font-black uppercase text-gray-400">Operator</th>
                 <th className="px-10 py-6 text-xs font-black uppercase text-gray-400">Action</th>
                 <th className="px-10 py-6 text-xs font-black uppercase text-gray-400">Time</th>
               </tr>
             </thead>
             <tbody>
               {state.logs.map(l => (
                 <tr key={l.id} className="border-t border-gray-50">
                   <td className="px-10 py-6 font-bold">{l.staffId}</td>
                   <td className="px-10 py-6 italic">{l.action}</td>
                   <td className="px-10 py-6 text-xs text-gray-400">{new Date(l.timestamp).toLocaleString()}</td>
                 </tr>
               ))}
             </tbody>
           </table>
        </div>
      )}

      {tab === 'security' && (
        <div className="bg-white p-12 rounded-[3.5rem] border border-gray-100 shadow-xl space-y-12 animate-in fade-in duration-500">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
             <div className="space-y-8">
                <h3 className="text-2xl font-black text-gray-900 flex items-center gap-3"><ShieldAlert className="text-rose-600" /> Root Credential Management</h3>
                <div className="p-8 bg-gray-50 rounded-[2.5rem] border border-gray-200 space-y-6">
                   <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Update Admin Username</label>
                      <div className="relative">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input type="text" value={editAdmin.username} onChange={e => setEditAdmin({...editAdmin, username: e.target.value})} className="w-full pl-10 p-4 bg-white border border-gray-200 rounded-2xl font-black outline-none" />
                      </div>
                   </div>
                   <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">New Master Password <span className="text-rose-400 font-normal">(Leave blank to keep current)</span></label>
                      <div className="relative">
                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input 
                          type={showPassword ? "text" : "password"} 
                          placeholder="••••••••" 
                          value={editAdmin.password} 
                          onChange={e => setEditAdmin({...editAdmin, password: e.target.value})} 
                          className="w-full pl-10 p-4 bg-white border border-gray-200 rounded-2xl font-black outline-none" 
                        />
                        <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                   </div>
                   <div className="space-y-1">
                      <label className="text-[10px] font-black text-rose-500 uppercase tracking-widest ml-1">Update Secret Login PIN (4 Digits)</label>
                      <div className="relative">
                        <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-500" />
                        <input 
                          type="password" 
                          maxLength={4} 
                          value={editAdmin.pin} 
                          onChange={e => setEditAdmin({...editAdmin, pin: e.target.value})} 
                          className="w-full pl-10 p-4 bg-white border-2 border-rose-100 rounded-2xl font-black text-center tracking-[1em] focus:ring-2 focus:ring-rose-500 outline-none" 
                        />
                      </div>
                      <p className="text-[9px] text-rose-400 font-bold uppercase text-center mt-2">This PIN is required for every login</p>
                   </div>
                   <button onClick={handleSaveAdminCreds} className="w-full py-5 bg-gray-900 text-white font-black rounded-3xl flex items-center justify-center gap-2 shadow-xl hover:bg-black active:scale-95 transition-all">
                     <Save className="w-5 h-5" /> Update Root Credentials
                   </button>
                </div>
             </div>

             <div className="space-y-8">
                <h3 className="text-2xl font-black text-gray-900 flex items-center gap-3"><Globe className="text-emerald-500" /> Access Control List</h3>
                <div className="p-8 bg-gray-50 rounded-[2.5rem] border border-gray-200 space-y-4">
                  <p className="text-xs text-gray-500 font-bold">Authorized Staff IPs</p>
                  <div className="flex gap-2 flex-wrap">
                    {state.security.allowedStaffIPs.length > 0 ? (
                      state.security.allowedStaffIPs.map(ip => <span key={ip} className="px-3 py-1 bg-white rounded-lg text-[10px] font-black border border-gray-100 flex items-center gap-2">{ip} <button onClick={() => {
                        setState(prev => ({
                          ...prev, 
                          security: {...prev.security, allowedStaffIPs: prev.security.allowedStaffIPs.filter(i => i !== ip)},
                          logs: [createLog('admin', `[Security] Removed authorized IP: ${ip}`), ...prev.logs]
                        }));
                      }} className="text-rose-500">×</button></span>)
                    ) : (
                      <span className="text-[10px] font-bold text-gray-400">All IPs allowed (Not secure)</span>
                    )}
                  </div>
                  <div className="space-y-2 pt-4">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Whitelist New IP</label>
                    <div className="flex gap-2">
                      <input id="new-ip" type="text" placeholder="e.g. 192.168.1.1" className="flex-1 p-4 bg-white border border-gray-200 rounded-2xl font-bold text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                      <button onClick={() => {
                        const v = (document.getElementById('new-ip') as HTMLInputElement).value;
                        if (v) {
                          setState(prev => ({ 
                            ...prev, 
                            security: { ...prev.security, allowedStaffIPs: [...prev.security.allowedStaffIPs, v] },
                            logs: [createLog('admin', `[Security] Whitelisted new IP: ${v}`), ...prev.logs]
                          }));
                          (document.getElementById('new-ip') as HTMLInputElement).value = '';
                        }
                      }} className="px-6 bg-emerald-600 text-white font-black rounded-2xl hover:bg-emerald-700 transition-all">Add</button>
                    </div>
                  </div>
                </div>
             </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
