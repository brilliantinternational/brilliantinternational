
import React, { useState, useEffect } from 'react';
import { Profile, Gender, MaritalStatus, Sibling } from '../types';
import { RELIGIONS, CASTES, DISTRICTS, EDUCATION_LEVELS, EDUCATION_SUBJECTS, OCCUPATIONS, BODY_TYPES, STATES, COUNTRIES } from '../constants';
import { generateProfileId, applyWatermark } from '../utils';
import { 
  Camera, Heart, ArrowRight, Loader2, Lock, Eye, EyeOff, ShieldCheck, 
  AlertCircle, Check, X, Plus, Trash2, Users, Stethoscope, FileText, 
  Briefcase, GraduationCap, MapPin, Globe, MessageSquare, User, CheckCircle 
} from 'lucide-react';

const isDegree = (level: string) => {
  const degrees = ['B.A', 'B.Sc', 'B.Com', 'B.Tech / B.E', 'M.A', 'M.Sc', 'M.Com', 'M.Tech', 'MBA', 'PhD'];
  return degrees.includes(level);
};

interface RegisterProps {
  onRegister: (profile: Profile) => void;
  profiles: Profile[];
}

const Register: React.FC<RegisterProps> = ({ onRegister, profiles }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<any>({
    phone: '',
    firstName: '',
    lastName: '',
    nickname: '',
    password: '',
    confirmPassword: '',
    gender: Gender.MALE,
    age: 25,
    height: 165,
    religionId: 1,
    casteId: 1,
    isPentecostal: false,
    isBrethren: false,
    maritalStatus: MaritalStatus.FIRST,
    educationLevel: 'B.A',
    educationSubject: '',
    educationOthers: '',
    occupation: 'Software Engineer',
    occupationOthers: '',
    fatherName: '',
    fatherOccupation: 'Retired',
    motherName: '',
    motherOccupation: 'House Wife / Home Maker',
    siblings: [],
    bodyType: 'Average',
    healthDisclosure: '',
    additionalDetails: '',
    preferredHeightMin: 140,
    preferredHeightMax: 190,
    preferredReligions: [],
    preferredCastes: {}, 
    preferredDistricts: [],
    preferredStates: ['Kerala'],
    preferredStateOthers: '',
    preferredCountries: ['India'],
    preferredCountryOthers: '',
    preferredOccupations: [],
    preferredOccupationOthers: '',
    preferredPentecostal: false,
    preferredBrethren: false,
    preferenceRemarks: '',
    country: 'India',
    countryOthers: '',
    state: 'Kerala',
    stateOthers: '',
    district: DISTRICTS[0],
    bio: '',
    photoUrl: ''
  });

  const [pwValidation, setPwValidation] = useState({
    length: false, upper: false, lower: false, number: false, special: false, match: false
  });

  useEffect(() => {
    const p = formData.password;
    const specialCharRegex = /[!@#$%^&*(),.?":{}|<>]/;
    setPwValidation({
      length: p.length >= 8,
      upper: /[A-Z]/.test(p),
      lower: /[a-z]/.test(p),
      number: /[0-9]/.test(p),
      special: specialCharRegex.test(p),
      match: p === formData.confirmPassword && p !== ''
    });
  }, [formData.password, formData.confirmPassword]);

  const isPasswordValid = pwValidation.length && pwValidation.upper && pwValidation.lower && pwValidation.number && pwValidation.special && pwValidation.match;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData((prev: any) => ({ ...prev, [name]: finalValue }));
    if (error) setError(null);
  };

  const addSibling = () => {
    const newSib: Sibling = { id: Date.now().toString(), type: 'Brother', status: 'Unmarried' };
    setFormData((prev: any) => ({ ...prev, siblings: [...prev.siblings, newSib] }));
  };

  const updateSibling = (id: string, field: keyof Sibling, value: string) => {
    setFormData((prev: any) => ({
      ...prev,
      siblings: prev.siblings.map((s: Sibling) => s.id === id ? { ...s, [field]: value } : s)
    }));
  };

  const removeSibling = (id: string) => {
    setFormData((prev: any) => ({ ...prev, siblings: prev.siblings.filter((s: Sibling) => s.id !== id) }));
  };

  const togglePreference = (key: string, value: any) => {
    setFormData((prev: any) => {
      const current = prev[key] || [];
      const updated = current.includes(value) 
        ? current.filter((v: any) => v !== value) 
        : [...current, value];
      
      const updatedCastes = { ...prev.preferredCastes };
      if (key === 'preferredReligions' && !updated.includes(value)) {
        delete updatedCastes[value];
      }
      return { ...prev, [key]: updated, preferredCastes: updatedCastes };
    });
  };

  const toggleCastePreference = (religionId: number, casteIndex: number) => {
    setFormData((prev: any) => {
      const current = prev.preferredCastes[religionId] || [];
      let updated;
      if (casteIndex === 0) {
        updated = current.includes(0) ? [] : [0];
      } else {
        updated = current.includes(casteIndex)
          ? current.filter((v: any) => v !== casteIndex)
          : [...current.filter((v: any) => v !== 0), casteIndex];
      }
      return { ...prev, preferredCastes: { ...prev.preferredCastes, [religionId]: updated } };
    });
  };

  const handleNextStep = () => {
    if (step === 1 && (!formData.phone || !formData.firstName || !formData.lastName || !formData.nickname)) {
      return setError("Mandatory identity fields must be filled.");
    }
    if (step === 3 && (!formData.fatherName || !formData.motherName)) {
      return setError("Parent names are mandatory.");
    }
    setError(null);
    setStep(step + 1);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLoading(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const watermarked = await applyWatermark(reader.result as string);
          setFormData((prev: any) => ({ ...prev, photoUrl: watermarked }));
        } catch (err) {
          setError("Image processing failed.");
        } finally {
          setLoading(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.photoUrl) return setError("Profile photo is mandatory.");
    setIsSubmitting(true);
    await new Promise(r => setTimeout(r, 1000));
    onRegister({ ...formData, id: generateProfileId(formData.nickname) } as Profile);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-[3rem] shadow-2xl border border-rose-50 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-5 min-h-[700px]">
          <div className="bg-rose-600 p-8 text-white md:col-span-1 hidden md:flex flex-col">
            <h2 className="text-2xl font-black mb-12">Portal</h2>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5, 6, 7].map(s => (
                <div key={s} className={`flex items-center gap-3 ${step === s ? 'opacity-100 scale-110 translate-x-1' : 'opacity-40'} transition-all`}>
                  <div className="w-8 h-8 rounded-full bg-white text-rose-600 flex items-center justify-center text-[10px] font-black shadow-lg">{s}</div>
                  <span className="text-[10px] font-black uppercase tracking-widest">Step {s}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-8 md:p-12 md:col-span-4 flex flex-col">
            <form onSubmit={handleSubmit} className="flex-grow flex flex-col space-y-8">
              {error && <div className="p-4 bg-rose-50 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-2 animate-bounce"><AlertCircle className="w-4 h-4" />{error}</div>}

              {step === 1 && (
                <div className="space-y-6 animate-in slide-in-from-right">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><User className="text-rose-500" /> 1. Identity & Location</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="text" name="firstName" placeholder="First Name *" value={formData.firstName} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-rose-500" />
                    <input type="text" name="lastName" placeholder="Last Name *" value={formData.lastName} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-rose-500" />
                    <input type="text" name="nickname" placeholder="Nickname *" value={formData.nickname} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-rose-500" />
                    <input type="tel" name="phone" placeholder="Phone Number *" value={formData.phone} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-rose-500" />
                    
                    <select name="country" value={formData.country} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    {formData.country === 'Others' && (
                      <input type="text" name="countryOthers" placeholder="Specify Country *" value={formData.countryOthers} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold border-none" />
                    )}

                    <select name="state" value={formData.state} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {STATES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    {formData.state === 'Others' && (
                      <input type="text" name="stateOthers" placeholder="Specify State *" value={formData.stateOthers} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold border-none" />
                    )}

                    {formData.state === 'Kerala' && (
                      <select name="district" value={formData.district} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                        {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                      </select>
                    )}
                  </div>
                  <button type="button" onClick={handleNextStep} className="mt-auto w-full bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all">Continue <ArrowRight className="w-5 h-5" /></button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6 animate-in slide-in-from-right">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><GraduationCap className="text-rose-500" /> 2. Profession & Education</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <select name="educationLevel" value={formData.educationLevel} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {EDUCATION_LEVELS.map(e => <option key={e} value={e}>{e}</option>)}
                    </select>
                    {isDegree(formData.educationLevel) && (
                      <select name="educationSubject" value={formData.educationSubject} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                        <option value="">Select Subject</option>
                        {EDUCATION_SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    )}
                    <select name="occupation" value={formData.occupation} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                    {formData.occupation === 'Others' && (
                      <input type="text" name="occupationOthers" placeholder="Specify Job Details *" value={formData.occupationOthers} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold" />
                    )}
                  </div>
                  <div className="flex gap-4 mt-auto">
                    <button type="button" onClick={() => setStep(1)} className="px-8 py-5 bg-gray-100 font-bold rounded-2xl active:scale-95 transition-all">Back</button>
                    <button type="button" onClick={handleNextStep} className="flex-1 bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl active:scale-95 transition-all">Continue</button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6 animate-in slide-in-from-right">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><Users className="text-rose-500" /> 3. Family Heritage</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="text" name="fatherName" placeholder="Father's Name *" value={formData.fatherName} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold" />
                    <select name="fatherOccupation" value={formData.fatherOccupation} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                    <input type="text" name="motherName" placeholder="Mother's Name *" value={formData.motherName} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold" />
                    <select name="motherOccupation" value={formData.motherOccupation} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">Siblings ({formData.siblings.length})</h4>
                      <button type="button" onClick={addSibling} className="px-4 py-2 bg-rose-50 text-rose-600 rounded-xl text-xs font-black flex items-center gap-1 hover:bg-rose-100 transition-all"><Plus className="w-3 h-3" /> Add Sibling</button>
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                      {formData.siblings.map((s: Sibling) => (
                        <div key={s.id} className="grid grid-cols-3 gap-3 p-3 bg-gray-50 rounded-2xl animate-in zoom-in border border-gray-100">
                          <select value={s.type} onChange={e => updateSibling(s.id, 'type', e.target.value as any)} className="p-2 bg-white rounded-lg text-xs font-bold">
                            <option>Brother</option>
                            <option>Sister</option>
                          </select>
                          <select value={s.status} onChange={e => updateSibling(s.id, 'status', e.target.value as any)} className="p-2 bg-white rounded-lg text-xs font-bold">
                            <option>Unmarried</option>
                            <option>Married</option>
                          </select>
                          <button type="button" onClick={() => removeSibling(s.id)} className="text-rose-400 hover:text-rose-600 flex justify-center items-center"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-4 mt-auto">
                    <button type="button" onClick={() => setStep(2)} className="px-8 py-5 bg-gray-100 font-bold rounded-2xl active:scale-95 transition-all">Back</button>
                    <button type="button" onClick={handleNextStep} className="flex-1 bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl active:scale-95 transition-all">Continue</button>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-6 animate-in slide-in-from-right">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><Stethoscope className="text-rose-500" /> 4. Health & Personal Info</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <select name="bodyType" value={formData.bodyType} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold">
                      {BODY_TYPES.map(bt => <option key={bt} value={bt}>{bt}</option>)}
                    </select>
                    <input type="number" name="height" placeholder="Height (cm)" value={formData.height} onChange={handleChange} className="p-4 bg-gray-50 rounded-2xl font-bold" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-rose-500 uppercase tracking-widest ml-1">Health Disclosures</label>
                    <textarea name="healthDisclosure" placeholder="Type health details here..." value={formData.healthDisclosure} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl h-24 font-bold outline-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-blue-500 uppercase tracking-widest ml-1">Self Description (Extra Details)</label>
                    <textarea name="additionalDetails" placeholder="Tell us more about yourself, your hobbies, values, etc..." value={formData.additionalDetails} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl h-32 font-bold outline-none" />
                  </div>
                  <div className="flex gap-4 mt-auto">
                    <button type="button" onClick={() => setStep(3)} className="px-8 py-5 bg-gray-100 font-bold rounded-2xl active:scale-95 transition-all">Back</button>
                    <button type="button" onClick={handleNextStep} className="flex-1 bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl active:scale-95 transition-all">Continue</button>
                  </div>
                </div>
              )}

              {step === 5 && (
                <div className="space-y-6 animate-in slide-in-from-right overflow-y-auto max-h-[600px] pr-2">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><Briefcase className="text-blue-500" /> 5. Partner Preference (Work & Place)</h3>
                  <div className="p-6 bg-blue-50 rounded-[2.5rem] border border-blue-100 space-y-6">
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Preferred Occupations (Multi-select)</label>
                      <div className="flex flex-wrap gap-1 p-3 bg-white/50 rounded-2xl max-h-48 overflow-y-auto">
                        {OCCUPATIONS.map(o => (
                          <button key={o} type="button" onClick={() => togglePreference('preferredOccupations', o)} className={`px-2 py-1.5 rounded-lg text-[9px] font-black transition-all ${formData.preferredOccupations.includes(o) ? 'bg-blue-600 text-white' : 'text-blue-400 bg-white'}`}>{o}</button>
                        ))}
                      </div>
                      <input type="text" name="preferredOccupationOthers" placeholder="Other Job Preference Box..." value={formData.preferredOccupationOthers} onChange={handleChange} className="w-full p-4 bg-white/70 rounded-2xl font-bold border border-blue-100 outline-none" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Preferred Countries</label>
                        <div className="flex flex-wrap gap-1 p-3 bg-white/50 rounded-2xl max-h-32 overflow-y-auto">
                          {COUNTRIES.map(c => (
                            <button key={c} type="button" onClick={() => togglePreference('preferredCountries', c)} className={`px-2 py-1.5 rounded-lg text-[9px] font-black transition-all ${formData.preferredCountries.includes(c) ? 'bg-blue-600 text-white' : 'text-blue-400 bg-white'}`}>{c}</button>
                          ))}
                        </div>
                        <input type="text" name="preferredCountryOthers" placeholder="Other Country Box..." value={formData.preferredCountryOthers} onChange={handleChange} className="w-full p-3 bg-white/70 rounded-xl font-bold border border-blue-100" />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Preferred States</label>
                        <div className="flex flex-wrap gap-1 p-3 bg-white/50 rounded-2xl max-h-32 overflow-y-auto">
                          {STATES.map(s => (
                            <button key={s} type="button" onClick={() => togglePreference('preferredStates', s)} className={`px-2 py-1.5 rounded-lg text-[9px] font-black transition-all ${formData.preferredStates.includes(s) ? 'bg-blue-600 text-white' : 'text-blue-400 bg-white'}`}>{s}</button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-4 mt-auto">
                    <button type="button" onClick={() => setStep(4)} className="px-8 py-5 bg-gray-100 font-bold rounded-2xl active:scale-95 transition-all">Back</button>
                    <button type="button" onClick={handleNextStep} className="flex-1 bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl active:scale-95 transition-all">Continue</button>
                  </div>
                </div>
              )}

              {step === 6 && (
                <div className="space-y-6 animate-in slide-in-from-right overflow-y-auto max-h-[600px] pr-2">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><Heart className="text-rose-500" /> 6. Partner Preference (Faith & Religion)</h3>
                  <div className="p-6 bg-rose-50 rounded-[2.5rem] border border-rose-100 space-y-6">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Religious Preferences</label>
                      <div className="flex flex-wrap gap-2">
                        {RELIGIONS.map(r => (
                          <button key={r.id} type="button" onClick={() => togglePreference('preferredReligions', r.id)} className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all ${formData.preferredReligions.includes(r.id) ? 'bg-rose-600 text-white' : 'text-rose-400 bg-white'}`}>{r.name}</button>
                        ))}
                      </div>
                      <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
                        {formData.preferredReligions.map((rid: number) => (
                          <div key={rid} className="space-y-2 p-4 bg-white/50 rounded-2xl">
                            <label className="text-[9px] font-black text-rose-400 uppercase">Castes for {RELIGIONS.find(r => r.id === rid)?.name}</label>
                            <div className="flex flex-wrap gap-1">
                              <button type="button" onClick={() => toggleCastePreference(rid, 0)} className={`px-2 py-1 rounded text-[8px] font-bold ${formData.preferredCastes[rid]?.includes(0) ? 'bg-rose-500 text-white' : 'text-rose-300'}`}>ALL</button>
                              {CASTES[rid]?.map((c, idx) => (
                                <button key={idx} type="button" disabled={formData.preferredCastes[rid]?.includes(0)} onClick={() => toggleCastePreference(rid, idx + 1)} className={`px-2 py-1 rounded text-[8px] font-bold ${formData.preferredCastes[rid]?.includes(idx + 1) ? 'bg-rose-500 text-white' : 'text-rose-300'}`}>{c}</button>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4 p-4 bg-white/50 rounded-2xl">
                      <p className="text-xs font-black text-rose-600 uppercase tracking-widest">Faith Toggles</p>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" name="preferredPentecostal" checked={formData.preferredPentecostal} onChange={handleChange} className="w-4 h-4 rounded text-rose-600" />
                          <span className="text-xs font-black text-rose-700">Pentecostal Only</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" name="preferredBrethren" checked={formData.preferredBrethren} onChange={handleChange} className="w-4 h-4 rounded text-rose-600" />
                          <span className="text-xs font-black text-rose-700">Brethren Only</span>
                        </label>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-rose-500 uppercase tracking-widest flex items-center gap-2"><MessageSquare className="w-4 h-4" /> Preference Remarks (Extra Box)</label>
                      <textarea name="preferenceRemarks" placeholder="Type specific requirements for your partner here..." value={formData.preferenceRemarks} onChange={handleChange} className="w-full p-4 bg-white/70 rounded-3xl h-32 font-bold outline-none" />
                    </div>
                  </div>
                  <div className="flex gap-4 mt-auto">
                    <button type="button" onClick={() => setStep(5)} className="px-8 py-5 bg-gray-100 font-bold rounded-2xl active:scale-95 transition-all">Back</button>
                    <button type="button" onClick={handleNextStep} className="flex-1 bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl active:scale-95 transition-all">Continue</button>
                  </div>
                </div>
              )}

              {step === 7 && (
                <div className="space-y-6 animate-in slide-in-from-right">
                  <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2"><ShieldCheck className="text-emerald-500" /> 7. Final Security</h3>
                  <div className="space-y-4">
                    <div className={`relative h-48 bg-gray-50 rounded-[3rem] border-2 border-dashed flex flex-col items-center justify-center overflow-hidden ${formData.photoUrl ? 'border-emerald-500' : 'border-gray-200'}`}>
                      {formData.photoUrl ? <img src={formData.photoUrl} className="w-full h-full object-cover" /> : <Camera className="text-gray-300" />}
                      <input type="file" accept="image/*" onChange={handlePhotoUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                      {loading && <Loader2 className="animate-spin text-rose-600" />}
                    </div>
                    <p className="text-[10px] text-gray-400 font-black uppercase text-center tracking-widest">Watermark "SoulLinks Matrimony" will be applied</p>
                  </div>
                  <div className="space-y-4">
                    <div className="relative">
                      <input type={showPassword ? "text" : "password"} name="password" placeholder="Create Password" value={formData.password} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl font-bold pr-12 outline-none" />
                      <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">{showPassword ? <EyeOff /> : <Eye />}</button>
                    </div>
                    <input type={showPassword ? "text" : "password"} name="confirmPassword" placeholder="Confirm Password" value={formData.confirmPassword} onChange={handleChange} className="w-full p-4 bg-gray-50 rounded-2xl font-bold outline-none" />
                  </div>
                  <div className="flex gap-4 mt-auto">
                    <button type="button" onClick={() => setStep(6)} className="px-8 py-5 bg-gray-100 font-bold rounded-2xl active:scale-95 transition-all">Back</button>
                    <button type="submit" disabled={!isPasswordValid || !formData.photoUrl || isSubmitting} className="flex-1 bg-rose-600 text-white font-black py-5 rounded-2xl shadow-xl disabled:bg-gray-300 transition-all active:scale-95">
                      {isSubmitting ? 'Securing Profile...' : 'Complete Secure Signup'}
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
