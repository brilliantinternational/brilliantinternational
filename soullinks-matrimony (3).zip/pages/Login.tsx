
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Heart, Phone, ArrowRight, ShieldCheck, User, Lock, Eye, EyeOff, ShieldAlert, Key } from 'lucide-react';

interface LoginProps {
  onLoginAttempt: (phone: string, password?: string) => void;
  onStaffLoginAttempt: (phone: string, password?: string) => void;
  onAdminLoginAttempt: (username: string, password: string, pin?: string) => void;
  onForgotPassword: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginAttempt, onStaffLoginAttempt, onAdminLoginAttempt, onForgotPassword }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [userType, setUserType] = useState<'user' | 'staff' | 'admin'>('user');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (userType === 'user') {
      if (phoneNumber.length < 10) return alert("Enter valid phone number");
      onLoginAttempt(phoneNumber, password);
    } else if (userType === 'staff') {
      onStaffLoginAttempt(phoneNumber, password);
    } else {
      if (!pin) return alert("Secret Login PIN is required");
      onAdminLoginAttempt(username, password, pin);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white p-8 md:p-12 rounded-[3.5rem] shadow-2xl border border-gray-100 w-full max-w-md space-y-8 animate-in fade-in zoom-in duration-500">
        
        <div className="flex p-1 bg-gray-100 rounded-2xl mb-4">
          <button 
            type="button"
            onClick={() => setUserType('user')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${userType === 'user' ? 'bg-white shadow-md text-rose-600' : 'text-gray-400'}`}
          >
            <User className="w-4 h-4" /> User
          </button>
          <button 
            type="button"
            onClick={() => setUserType('staff')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${userType === 'staff' ? 'bg-white shadow-md text-rose-600' : 'text-gray-400'}`}
          >
            <ShieldCheck className="w-4 h-4" /> Staff
          </button>
          <button 
            type="button"
            onClick={() => setUserType('admin')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${userType === 'admin' ? 'bg-white shadow-md text-rose-600' : 'text-gray-400'}`}
          >
            <ShieldAlert className="w-4 h-4" /> Admin
          </button>
        </div>

        <div className="text-center space-y-2">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto shadow-lg rotate-12 mb-6 transition-colors duration-500 ${userType === 'user' ? 'bg-rose-600' : userType === 'staff' ? 'bg-indigo-600' : 'bg-gray-900'}`}>
            <Heart className="w-8 h-8 text-white fill-white" />
          </div>
          <h1 className="text-3xl font-black text-gray-900">
            {userType === 'user' ? 'Member Login' : userType === 'staff' ? 'Staff Desk' : 'Root Console'}
          </h1>
          <p className="text-gray-500 text-sm font-bold">
            {userType === 'admin' ? 'Authorized access only' : 'Enter credentials to continue'}
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            {userType === 'admin' ? (
              <>
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
                  <input
                    type="text"
                    placeholder="Admin Username"
                    required
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
                <div className="relative group">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Master Password"
                    required
                    className="w-full pl-12 pr-12 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                <div className="relative group">
                  <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
                  <input
                    type="password"
                    placeholder="Secret Login PIN"
                    required
                    maxLength={4}
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold text-center tracking-[1em]"
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="relative group">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    required
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>
                <div className="relative group">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-rose-500 transition-colors" />
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Password"
                    required
                    className="w-full pl-12 pr-12 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all font-bold"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button 
                    type="button" 
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-rose-600 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </>
            )}
          </div>

          <div className="flex justify-between items-center">
            {userType === 'admin' ? (
               <Link to="/admin-setup" className="text-xs font-black text-rose-600 hover:underline uppercase tracking-widest">
                 First Time? Setup Admin
               </Link>
            ) : (
              <button 
                type="button" 
                onClick={onForgotPassword}
                className="text-xs font-black text-rose-600 hover:underline uppercase tracking-widest"
              >
                Forgot Password?
              </button>
            )}
            {userType === 'user' && (
              <Link to="/register" className="text-xs font-black text-gray-400 hover:text-rose-600 transition-colors uppercase tracking-widest">
                New user? <span className="text-rose-600">Join Free</span>
              </Link>
            )}
          </div>

          <button
            type="submit"
            className={`w-full text-white py-5 rounded-2xl font-black text-lg transition shadow-xl flex items-center justify-center gap-2 active:scale-95 ${userType === 'admin' ? 'bg-gray-900 hover:bg-black' : 'bg-rose-600 hover:bg-rose-700'}`}
          >
            Access Account <ArrowRight className="w-5 h-5" />
          </button>
        </form>

        <div className="text-center pt-4 border-t border-gray-50">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest leading-relaxed">
            Strict Non-Dating Policy Enforced. Authorized Personnel Only.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
